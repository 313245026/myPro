package main

import (
	"fmt"
	"io"
	"log"
	"net/http"

)

func main() {
    
	initHttpHandle()
	err := http.ListenAndServe(":8080", nil)
	if err != nil {
	log.Fatal("ListenAndServe: ", err.Error())
	fmt.Println("Hello, World!")
	}
}

func helloHandler(rsp http.ResponseWriter, req *http.Request) {

	io.WriteString(rsp, "Hello, world!321321")
}


func initHttpHandle(){
	http.HandleFunc("/hello", helloHandler)

	http.HandleFunc("/api/course/queryByTeacher", queryByTeacher)								//请求老师授课表boya
	http.HandleFunc("/api/course/queryByStudentr", queryByStudentr)								//请求学生课程表boya
	http.HandleFunc("/api/course/getByTeacher",getByTeacher)									// 获取老师详情boya
	http.HandleFunc("/api/course/getByStudent",getByStudent)									//获取学生详情boya
	http.HandleFunc("/api/course/queryChatperForFront",queryChatperForFront)					//获取章节信息boya
	http.HandleFunc("/api/user/editInfoForTeacher",editInfoForTeacher)							//编辑其它人的个人数据lg
	http.HandleFunc("/api/interaction/collectCourse",collectCourse)								// 收藏/取消收藏课程lg
	http.HandleFunc("/api/system/suggest",suggest)												//问题反馈lg
	http.HandleFunc("/api/course/queryQqGroups",queryQqGroups)									//查询qq号lg
	http.HandleFunc("/api/interaction/checkCollectCourse",checkCollectCourse)					// 检查课程是否已收藏lg
	http.HandleFunc("/api/study/getRole",getRole)												//获取角色fzw
	http.HandleFunc("/api/course/getRealtime",getRealtime)										// 获取实现信息fzw
	http.HandleFunc("/api/course/addListenRecord",addListenRecord)								// 添加播放记录fzw
	http.HandleFunc("/api/course/queryListenRecord",queryListenRecord)							// 查询播放记录fzw
	http.HandleFunc("/api/cate/query",query)													//查询分类fzw
	http.HandleFunc("/api/course/queryByTeachQuality",queryByTeachQuality)						// 得到教质课程boya
	http.HandleFunc("/api/user/teacherInfo",teacherInfo)										// 得到自己的老师信息fzw
	http.HandleFunc("/api/live/start",start)													// 上课psz
	http.HandleFunc("/api/live/stop",stop)														// 下课psz
	http.HandleFunc("/api/live/enter",enter)													//进入教室boya
	http.HandleFunc("/api/live/qcloud/get-login-sign",get_login_sign)							// 得到腾讯签名fzw
	http.HandleFunc("/api/live/mute/cancel",cancel)												// 取消禁言psz
	http.HandleFunc("/api/live/mute/activate",activate)
	http.HandleFunc("/api/live/qcloud/get-publish-type",get_publish_type)						//得到服务器的推流类型
	http.HandleFunc("/api/interaction/send-flower",send_flower)									//送花psz
	http.HandleFunc("/api/user-tag/add-or-modify",add_or_modify)								// 习惯用户标记fzw
	http.HandleFunc("/api/user-tag/batch-query",batch_query)									//批量获取用户标记fzw
	http.HandleFunc("/api/interaction/query-raiseHandList",query_raiseHandList)					// 查询麦序gqx
	http.HandleFunc("/api/interaction/raise-hand",raise_hand)									// 学生申请连麦gqx
	http.HandleFunc("/api/interaction/agree-in-channel",agree_in_channel)						//老师同意连麦gqx
	http.HandleFunc("/api/interaction/out-channel",out_channel)									// 学生主动下麦gqx
	http.HandleFunc("/api/interaction/kick-student",kick_student)								// 老师提学生下麦gqx
	http.HandleFunc("/api/interaction/invite-student",invite_student)							// 老师邀请学生上麦gqx
	http.HandleFunc("/api/interaction/accept-invite",accept_invite)								// 学生同意连麦gqx
	http.HandleFunc("/api/interaction/reject-invite",reject_invite)								// 学生拒绝连麦gqx
	http.HandleFunc("/api/interaction/in-channel",in_channel)									// 学生混流gqx
	http.HandleFunc("/api/interaction/get-others-info",get_others_info)							// 得到别人信息 gqx
	http.HandleFunc("/api/course/update-function-config",update_function_config)				// 教室功能配置psz
	http.HandleFunc("/api/interaction/push-stream-fail",push_stream_fail)						//推流失败psz
	http.HandleFunc("/api/course/modify-chatroom-announcement",modify_chatroom_announcement)	// 修改公告psz
}

func query(rsp http.ResponseWriter, req *http.Request) {
	io.WriteString(rsp, "Hello, world!")
	
}
func queryListenRecord(rsp http.ResponseWriter, req *http.Request) {
	
}
func addListenRecord(rsp http.ResponseWriter, req *http.Request) {
	
}
func getRealtime(rsp http.ResponseWriter, req *http.Request) {
	
}
func getRole(rsp http.ResponseWriter, req *http.Request) {
	
}
func checkCollectCourse(rsp http.ResponseWriter, req *http.Request) {
	
}
func queryQqGroups(rsp http.ResponseWriter, req *http.Request) {
	
}
func suggest(rsp http.ResponseWriter, req *http.Request) {
	
}
func collectCourse(rsp http.ResponseWriter, req *http.Request) {
	
}
func editInfoForTeacher(rsp http.ResponseWriter, req *http.Request) {
	
}
func queryChatperForFront(rsp http.ResponseWriter, req *http.Request) {
	
}
func getByStudent(rsp http.ResponseWriter, req *http.Request) {
	
}
func getByTeacher(rsp http.ResponseWriter, req *http.Request) {
	
}
func queryByStudentr(rsp http.ResponseWriter, req *http.Request) {
	
}
func queryByTeacher(rsp http.ResponseWriter, req *http.Request) {
	
}
func modify_chatroom_announcement(rsp http.ResponseWriter, req *http.Request) {
	
}
func push_stream_fail(rsp http.ResponseWriter, req *http.Request) {
	
}
func update_function_config(rsp http.ResponseWriter, req *http.Request) {
	
}
func get_others_info(rsp http.ResponseWriter, req *http.Request) {
	
}
func in_channel(rsp http.ResponseWriter, req *http.Request) {
	
}
func reject_invite(rsp http.ResponseWriter, req *http.Request) {
	
}
func accept_invite(rsp http.ResponseWriter, req *http.Request) {
	
}
func invite_student(rsp http.ResponseWriter, req *http.Request) {
	
}
func kick_student(rsp http.ResponseWriter, req *http.Request) {
	
}
func out_channel(rsp http.ResponseWriter, req *http.Request) {
	
}
func agree_in_channel(rsp http.ResponseWriter, req *http.Request) {
	
}
func raise_hand(rsp http.ResponseWriter, req *http.Request) {
	
}
func query_raiseHandList(rsp http.ResponseWriter, req *http.Request) {
	
}
func batch_query(rsp http.ResponseWriter, req *http.Request) {
	
}
func add_or_modify(rsp http.ResponseWriter, req *http.Request) {
	
}
func send_flower(rsp http.ResponseWriter, req *http.Request) {
	
}
func get_publish_type(rsp http.ResponseWriter, req *http.Request) {
	
}
func activate(rsp http.ResponseWriter, req *http.Request) {
	
}
func cancel(rsp http.ResponseWriter, req *http.Request) {
	
}
func get_login_sign(rsp http.ResponseWriter, req *http.Request) {
	
}
func enter(rsp http.ResponseWriter, req *http.Request) {
	
}
func stop(rsp http.ResponseWriter, req *http.Request) {
	
}
func start(rsp http.ResponseWriter, req *http.Request) {
	
}
func teacherInfo(rsp http.ResponseWriter, req *http.Request) {
	
}
func queryByTeachQuality(rsp http.ResponseWriter, req *http.Request) {
	
}


