#include "UserDataCenterInterface.h"
#include <QUuid>
#include <QDebug>
#include <QDatetime>
#include <QtCore/QCoreApplication> 
#include <QCryptographicHash>
#include <iostream>
#include "../../public/public_def.h"
#include "../../public/BaseOperation/BaseOperation.h"

CUserDataCenterInterface* CUserDataCenterInterface::m_pUserDataCenterInterface = nullptr;

CUserDataCenterInterface::CUserDataCenterInterface()
	:m_Realm("https://res.shiguangkey.com/")
{

}

CUserDataCenterInterface::~CUserDataCenterInterface()
{

}

CUserDataCenterInterface* CUserDataCenterInterface::GetInstance()
{
    if (NULL == m_pUserDataCenterInterface)
    {
        m_pUserDataCenterInterface = new CUserDataCenterInterface();
    }

    return m_pUserDataCenterInterface;
}

void CUserDataCenterInterface::CreateGuid(std::string& strGuid)
{
	strGuid.resize(36);
	memset(&(strGuid[0]), 0, 36);
	QUuid id = QUuid::createUuid();
	memcpy(&(strGuid[0]), id.toString().toStdString().c_str() + 1, 36);
}

std::string CUserDataCenterInterface::GetNoRodGuid(std::string & strGuid)
{
	char guid[33] = {0};
	const char *pGuid = strGuid.c_str();
	int j = 0;
	for (int i = 0; i < strGuid.length(); i++)
	{
		if ('-' == pGuid[i])
		{
			continue;
		}
		guid[j++] = pGuid[i];
	}
	return std::string(guid);
}

void CUserDataCenterInterface::parseJson(Json::Value list, std::vector<CATE_INFO>& vecCateInfo)
{
	if (list.isArray() && list.size()>0)
	{
		for (int i = 0; i < list.size(); i++)
		{
			CATE_INFO stCateInfo;
			if (list[i]["cateId"].isInt())
			{
				stCateInfo.cateId = list[i]["cateId"].asInt();
			}
			if (list[i]["name"].isString()) {
				stCateInfo.name = list[i]["name"].asString();
			}

			parseJson(list[i]["subCates"], stCateInfo.vecCateInfo);
			vecCateInfo.push_back(stCateInfo);
		}
	}
}

void CUserDataCenterInterface::LoginVerify(std::string& strAccount, std::string& strPassword, User_Base_Data& objUserBaseData)
{
	std::string url = AUTH_URL;
    std::string rikUrlStr = url + "/api/login/standard";;
    rikUrlStr += "?account=";
    urlencode(strAccount);
    rikUrlStr += strAccount;
    rikUrlStr += "&password=";
    urlencode(strPassword);
    rikUrlStr += strPassword;

    std::string iResponseStr;
    int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
    if (0 != nResult)
    {
        objUserBaseData.err_code = nResult;
		objUserBaseData.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
    }

    if (iResponseStr.empty())
    {
        objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
    }

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (root.isNull())
	{
		objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		objUserBaseData.err_code = root["status"].asInt64();
		 
	}
		
	if (root["msg"].isString())
	{
		objUserBaseData.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		objUserBaseData.err_msgId = root["messageId"].asString();
	}

	if (0 == objUserBaseData.err_code && root["data"].isObject())
	{
		Json::Value data = root["data"];

		if (data["token"].isString())
		{
			objUserBaseData.token = data["token"].asString();
		}
	}
	else if (1010 == objUserBaseData.err_code  && root["data"].isObject())
	{
		Json::Value data = root["data"];
		if (data["users"].isArray())
		{
			Json::Value users = data["users"];
			for (int i = 0; i < users.size(); i++)
			{
				Account_Info stAccountInfo;
				if (users[i]["account"].isString())
				{
					stAccountInfo.accid = QString::fromStdString(users[i]["account"].asString());
				}

				if (users[i]["nickname"].isString())
				{
					stAccountInfo.nick = QString::fromStdString(users[i]["nickname"].asString());
				}
					
				if (users[i]["gmtCreate"].isInt64())
				{
					long long gmtCreate = users[i]["gmtCreate"].asInt64();
					stAccountInfo.gmtCreate = QString::number(gmtCreate);
				}
					
				if (users[i]["loginType"].isInt())
				{
					stAccountInfo.loginType = (Login_type)users[i]["loginType"].asInt();
				}

				if (users[i]["vipcount"].isInt())
				{
					stAccountInfo.vipCount = users[i]["vipcount"].asInt();
				}
				objUserBaseData.vecAccountInfo.push_back(stAccountInfo);
			}
		}	
	}

    return;
}

void CUserDataCenterInterface::GetPersonalInfo(std::string &token, User_Base_Data& objUserBaseData)
{
	objUserBaseData.token = token;
	
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/userInfo/mine";
	rikUrlStr += "?token=";
	rikUrlStr += token;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		objUserBaseData.err_code = nResult;
		objUserBaseData.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (root.isNull())
	{
		objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		objUserBaseData.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		objUserBaseData.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		objUserBaseData.err_msgId = root["messageId"].asString();
	}

	if (0 != objUserBaseData.err_code)
	{
		return;
	}
		
	if(root["data"].isObject() && root["data"]["userDetail"].isObject())
	{
		Json::Value userDetail = root["data"]["userDetail"];
		if (userDetail["account"].isString())
		{
			objUserBaseData.account = userDetail["account"].asString();
		}

		if (userDetail["uid"].isInt64())
		{
			objUserBaseData.userid = userDetail["uid"].asInt64();
		}

		if (userDetail["headImg"].isString())
		{
			objUserBaseData.ico = userDetail["headImg"].asString();
		}

		if (userDetail["qq"].isString())
		{
			objUserBaseData.qq = userDetail["qq"].asString();
		}

		if (userDetail["email"].isString())
		{
			objUserBaseData.email = userDetail["email"].asString();
		}

		if (userDetail["phone"].isString())
		{
			objUserBaseData.phone = userDetail["phone"].asString();
		}
		if (userDetail["nickname"].isString())
		{
			objUserBaseData.nick = userDetail["nickname"].asString();
		}
	}
	return;
}

void CUserDataCenterInterface::UserBaseDataModify(std::string &token, std::string& strModifyData, User_Data_Modify_Result& objModifyResult)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/update/userInfo";
    std::string iResponseStr;

	strModifyData = "token=" + token + strModifyData;

    int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strModifyData, iResponseStr);
    if (0 != nResult)
    {
        objModifyResult.err_code = nResult;
		objModifyResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
        return;
    }

    if (iResponseStr.empty())
    {
		objModifyResult.err_code = -1;
		objModifyResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
        return;
    }
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		objModifyResult.err_code = -1;
		objModifyResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["msg"].isString()) {
		objModifyResult.err_msg = root["msg"].asString();
	}
	if (root["status"].isInt64()) {
		objModifyResult.err_code = root["status"].asInt64();
	}
	if (root["messageId"].isString()) {
		objModifyResult.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject()) {
		Json::Value data = root["data"];
		if (data["headImg"].isString())
		{
			objModifyResult.headImsg = data["headImg"].asString();
		}
	}

    return;
}

void CUserDataCenterInterface::UserOtherDataModify(std::string &token, std::string& strModifyData, User_Data_Modify_Result& objModifyResult)
{
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/user/editInfoForTeacher";
	std::string iResponseStr;

	strModifyData = "token=" + token + strModifyData;

	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strModifyData, iResponseStr);
	if (0 != nResult)
	{
		objModifyResult.err_code = nResult;
		objModifyResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		objModifyResult.err_code = -1;
		objModifyResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	if (root["status"].isInt64())
		objModifyResult.err_code = root["status"].asInt64();
	if (root["msg"].isString())
		objModifyResult.err_msg = root["msg"].asString();
	if (root["messageId"].isString())
	{
		objModifyResult.err_msgId = root["messageId"].asString();
	}
}

void CUserDataCenterInterface::GetTeacherCourse(std::string& strUserToken, int page, int pageSize, Course_Result& stCourseResult)
{
	char szOption[256] = { 0 };
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/course/queryByTeacher";

	rikUrlStr += "?token=" + strUserToken;
	sprintf(szOption, "&pageIndex=%d&pageSize=%d", page, pageSize);
	rikUrlStr += szOption;

	std::string iResponseStr;

	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCourseResult.err_code = nResult;
		stCourseResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr,root);

	if (root.isNull())
	{
	    stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCourseResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCourseResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCourseResult.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject())
	{
		Json::Value data = root["data"];
		if (data["count"].isInt64())
		{
			stCourseResult.totalCount = data["count"].asInt64();
		}
		if (data["courses"].isArray()) {
			Json::Value courses = data["courses"];
			Course_Info stCourseInfo;
			for (int i = 0; i < courses.size(); i++)
			{
				if (courses[i]["id"].isInt64()) {
					stCourseInfo.id = courses[i]["id"].asInt64();
				}
				if (courses[i]["classId"].isInt())
				{
					stCourseInfo.classId = courses[i]["classId"].asInt();
				}

				if (courses[i]["period"].isInt())
				{
					stCourseInfo.period = courses[i]["period"].asInt();
				}

				if (courses[i]["title"].isString()) {
					stCourseInfo.title = courses[i]["title"].asString();
				}
				if (courses[i]["cover"].isString()) {
					stCourseInfo.cover = courses[i]["cover"].asString();
					stCourseInfo.cover = m_Realm + stCourseInfo.cover; 
				}
				if (courses[i]["typeDicFk"].isInt64()) {
					stCourseInfo.courseType = courses[i]["typeDicFk"].asInt64();
				}
				if (courses[i]["roleType"].isString()) {
					std::string strRoleType = courses[i]["roleType"].asString();
					stCourseInfo.role = QString::fromStdString(strRoleType).toInt(0, 10);
				}
				if (courses[i]["liveStatusDicFk"].isString()) {
					QString liveStatus	= QString::fromStdString(courses[i]["liveStatusDicFk"].asString());
					stCourseInfo.liveStatus = liveStatus.toInt();
				}
				if (courses[i]["price"].isDouble()) {
					double price = courses[i]["price"].asDouble();
					stCourseInfo.price = QString::number(price).toStdString();
				}
				if (courses[i]["schoolName"].isString()) {
					stCourseInfo.schoolName = courses[i]["schoolName"].asString();
				}
				if (courses[i]["unshelveDicFk"].isInt64()) {
					stCourseInfo.unshelveDicFk = courses[i]["unshelveDicFk"].asInt64();
				}
				if (courses[i]["shangkeStatusDicFk"].isInt64()) {
					stCourseInfo.process = courses[i]["shangkeStatusDicFk"].asInt64();
				}

				if (courses[i]["startTime"].isInt64())
				{
					long long ltime = courses[i]["startTime"].asInt64();
					QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
					stCourseInfo.nextChapterTime = dateTime.toString("yyyy-MM-dd hh:mm:ss").toStdString();
				}
				if (courses[i]["endChapterNumber"].isInt64()) {
					stCourseInfo.endChapterNumber = courses[i]["endChapterNumber"].asInt64();
				}
				if (courses[i]["chapterNum"].isInt64()) {
					stCourseInfo.chapterNumber = courses[i]["chapterNum"].asInt64();
				}
				if (courses[i]["mainTeacher"].isString()) {
					stCourseInfo.teacherName = courses[i]["mainTeacher"].asString();
				}
				stCourseResult.CourseInfo.push_back(stCourseInfo);
			}
		}
	}
	return;
}

void CUserDataCenterInterface::GetStudentCourse(std::string& strUserToken, int page, int pageSize, Course_Result& stCourseResult)
{
	char szOption[256] = { 0 };
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/course/queryByStudent";
	rikUrlStr += "?token=" + strUserToken;
	sprintf(szOption, "&pageIndex=%d&pageSize=%d", page, pageSize);
	rikUrlStr += szOption;
	
	std::string iResponseStr;
	

	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	QString str = QString::fromStdString(iResponseStr);
	if (0 != nResult)
	{
		stCourseResult.err_code = nResult;
		stCourseResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::GetStudentCourse(): post data error (%s)", CHttpClient::GetInstance()->GetErrorStr(nResult));
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::GetStudentCourse(): request return string is empty!");
		return;
	}

	
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::GetStudentCourse(): request return string is empty!");
		return;
	}

	if (root["status"].isInt64())
	{
		stCourseResult.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		stCourseResult.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		stCourseResult.err_msgId = root["messageId"].asString();
	}

	if (0 != stCourseResult.err_code)
	{
		return;
	}

	if (root["data"].isObject())
	{
		Json::Value  data = root["data"];
		if (data["count"].isInt())
		{
			stCourseResult.totalCount = data["count"].asInt();
		}

		if (data["courses"].isArray())
		{
			Json::Value courses = data["courses"];
			for (int i = 0; i < courses.size(); i++)
			{
				Course_Info stCourseInfo;
				if (courses[i]["id"].isInt())
				{
					stCourseInfo.id = courses[i]["id"].asInt();
				}
				if (courses[i]["classIdFk"].isInt())
				{
					stCourseInfo.classId = courses[i]["classIdFk"].asInt();
				}

				if (courses[i]["period"].isInt())
				{
					stCourseInfo.period = courses[i]["period"].asInt();
				}

				if (courses[i]["placementStatus"].isInt())
				{
					stCourseInfo.placementStatus = courses[i]["placementStatus"].asInt();
				}

				if (courses[i]["title"].isString())
				{
					stCourseInfo.title = courses[i]["title"].asString();
				}

				if (courses[i]["cover"].isString())
				{
					stCourseInfo.cover = courses[i]["cover"].asString();
					stCourseInfo.cover = m_Realm + stCourseInfo.cover;
				}

				if (courses[i]["typeDicFk"].isInt())
				{
					stCourseInfo.courseType = courses[i]["typeDicFk"].asInt();
				}

				stCourseInfo.role = 5703;

				if (courses[i]["liveStatusDicFk"].isInt())
				{
					stCourseInfo.liveStatus = courses[i]["liveStatusDicFk"].asInt();
				}

				if (courses[i]["schoolName"].isString())
				{
					stCourseInfo.schoolName = courses[i]["schoolName"].asString();
				}

				if (courses[i]["unshelveDicFk"].isInt())
				{
					stCourseInfo.unshelveDicFk = courses[i]["unshelveDicFk"].asInt();
				}

				if (courses[i]["shangkeStatusDicFk"].isInt())
				{
					stCourseInfo.shangkeStatusDicFk = courses[i]["shangkeStatusDicFk"].asInt();
				}

				if (courses[i]["endChapterNumber"].isInt())
				{
					stCourseInfo.endChapterNumber = courses[i]["endChapterNumber"].asInt();
				}

				if (courses[i]["chapterNum"].isInt())
				{
					stCourseInfo.chapterNumber = courses[i]["chapterNum"].asInt();
				}

				if (courses[i]["mainTeacher"].isString())
				{
					stCourseInfo.teacherName = courses[i]["mainTeacher"].asString();
				}

				if (courses[i]["startTime"].isInt64())
				{
					long long ltime = courses[i]["startTime"].asInt64();
					QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
					stCourseInfo.nextChapterTime = dateTime.toString("yyyy-MM-dd hh:mm:ss").toStdString();
				}

				stCourseResult.CourseInfo.push_back(stCourseInfo);
			}
		}
	}
}
 
void CUserDataCenterInterface::CollectCancelCourse(std::string& strUserToken, int nCourseId, unsigned int status, Collect_Cancel_Course_Result& stCollectCancelResult)
{
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/interaction/collectCourse";
	std::string iResponseStr;

	std::string strPara;
	strPara = "token=" + strUserToken +"&courseId=" + QString::number(nCourseId, 10).toStdString();
	strPara = strPara + "&status=" + QString::number(status, 10).toStdString();
	//LOG_DEBUG("CUserDataCenterInterface::CollectCancelCourse() request post string Begin str:%s", strPara.c_str());

	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stCollectCancelResult.err_code = nResult;
		stCollectCancelResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCollectCancelResult.err_code = -1;
		stCollectCancelResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCollectCancelResult.err_code = -1;
		stCollectCancelResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCollectCancelResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCollectCancelResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCollectCancelResult.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject())
	{
		Json::Value  data = root["data"];
		if (data["result"].isInt())
		{
			int result = data["result"].asInt();
			if (1 == result)
				stCollectCancelResult.result = 1;
			else
				stCollectCancelResult.result = 0;
		}
	}
	return;
}

void CUserDataCenterInterface::GetCollectCourse(std::string& strUserToken, int pageIndex, int pageSize, Course_Result& stCourseResult)
{
	char szOption[256] = { 0 };
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/interaction/queryCollectCourse";
	rikUrlStr += "?token=" + strUserToken;
	sprintf(szOption, "&pageIndex=%d&pageSize=%d", pageIndex, pageSize);
	rikUrlStr += szOption;

	std::string iResponseStr;
	

	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCourseResult.err_code = nResult;
		stCourseResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();	
		return;
	}
	if (root["status"].isInt64())
	{
		stCourseResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCourseResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCourseResult.err_msgId = root["messageId"].asString();
	}
	
			
	if (root["data"].isObject() && root["data"]["list"].isArray())
	{
		
		if (root["data"]["count"].isInt())
		{
			stCourseResult.totalCount = root["data"]["count"].asInt();
		}
		
		Json::Value list = root["data"]["list"];
		int iCourseCount = list.size();
		if (pageSize == iCourseCount)
		{
			stCourseResult.isFetchAll = true;
		}
		for (int i = 0; i < list.size();i++) {
			
			Course_Info stCourseInfo;
			if (list[i]["courseId"].isInt64())
				stCourseInfo.id = list[i]["courseId"].asInt64();
			if (list[i]["title"].isString())
				stCourseInfo.title = list[i]["title"].asString();
			if (list[i]["cover"].isString())
			{
				stCourseInfo.cover = list[i]["cover"].asString();
				stCourseInfo.cover = m_Realm + stCourseInfo.cover;
			}
			if (list[i]["courseType"].isInt64())
				stCourseInfo.courseType = list[i]["courseType"].asInt64();

			//stCourseInfo.nextChapterTime = remove_tail(list[i]["nextChapterTime"].asString());
			if (list[i]["nextChapterTime"].isInt64())
			{
				long long ltime = list[i]["nextChapterTime"].asInt64();
				QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
				stCourseInfo.nextChapterTime = dateTime.toString("yyyy-MM-dd hh:mm:ss").toStdString();
			}

			if (list[i]["liveStatus"].isInt64())
				stCourseInfo.liveStatus = list[i]["liveStatus"].asInt64();
			if (list[i]["applyNum"].isInt64())
				stCourseInfo.applyNum = list[i]["applyNum"].asInt64();
			if (list[i]["schoolName"].isString())
				stCourseInfo.schoolName = list[i]["schoolName"].asString();
			if (list[i]["price"].isDouble()) {
				double price = list[i]["price"].asDouble();
				stCourseInfo.price = QString::number(price).toStdString();
			}
			if (list[i]["sortLevel"].isInt64())
				stCourseInfo.sortLevel = list[i]["sortLevel"].asInt64();
			if (list[i]["userId"].isInt64())
				stCourseInfo.userId = list[i]["userId"].asInt64();
			if (list[i]["schoolId"].isInt64())
				stCourseInfo.schoolId = list[i]["schoolId"].asInt64();
			if (list[i]["endChapterNumber"].isInt64())
				stCourseInfo.endChapterNumber = list[i]["endChapterNumber"].asInt64();
			if (list[i]["chapterNumber"].isInt64())
				stCourseInfo.chapterNumber = list[i]["chapterNumber"].asInt64();

			stCourseResult.CourseInfo.push_back(stCourseInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::GetSignupCourse(std::string& strUserToken, int pageIndex, int pageSize, Course_Result& stCourseResult)
{
	char szOption[256] = { 0 };
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/interaction/querySignupCourse";
	rikUrlStr += "?token=" + strUserToken;
	sprintf(szOption, "&pageIndex=%d&pageSize=%d", pageIndex, pageSize);
	rikUrlStr += szOption;

	std::string iResponseStr;


	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCourseResult.err_code = nResult;
		stCourseResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();		
		return;
	}
	if (root["status"].isInt64())
	{
		stCourseResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCourseResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCourseResult.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["courseList"].isObject())
	{
		Json::Value courseList = root["data"]["courseList"];
		for (int i = 0; i < courseList.size(); i++)
		{
			Course_Info stCourseInfo;
			if (courseList[i]["courseId"].isInt64())
			{
				stCourseInfo.id = courseList[i]["courseId"].asInt64();
			}
			stCourseResult.CourseInfo.push_back(stCourseInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::CreateImageCode(Image_Code_Result& stImageCodeResult)
{
	std::string uniqueId;
	CreateGuid(uniqueId);
	stImageCodeResult.uniqueId = uniqueId;
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/verify/imageCode/create";
	std::string iResponseStr;

	std::string strPara;
	strPara = "uniqueId=" + uniqueId;
	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	
	if (0 != nResult)
	{
		stImageCodeResult.err_code = nResult;
		stImageCodeResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stImageCodeResult.err_code = -1;
		stImageCodeResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stImageCodeResult.err_code = -1;
		stImageCodeResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stImageCodeResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stImageCodeResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stImageCodeResult.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject())
	{
		Json::Value data = root["data"];
		if (data["base64Image"].isString())
		{
			stImageCodeResult.image_info = data["base64Image"].asString();
			if (stImageCodeResult.image_info != "")
				stImageCodeResult.result = 1;
			else
				stImageCodeResult.result = 0;
		}
	}
	return;
}

void CUserDataCenterInterface::SendSMSIdentifyCode(std::string& phoneNumber, Send_SMS_Identify_Code_Result& stSendSMSIdentifyComdResult)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/verify/sms/send";
	std::string iResponseStr;

	std::string strPara;
	strPara = "phone=" + phoneNumber;
	

	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stSendSMSIdentifyComdResult.err_code = nResult;
		stSendSMSIdentifyComdResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stSendSMSIdentifyComdResult.err_code = -1;
		stSendSMSIdentifyComdResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stSendSMSIdentifyComdResult.err_code = -1;
		stSendSMSIdentifyComdResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();	
		return;
	}
	if (root["status"].isInt64())
	{
		stSendSMSIdentifyComdResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stSendSMSIdentifyComdResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stSendSMSIdentifyComdResult.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::CheckImageIdentifyCode(std::string& imageCode, std::string &uniqueId, Image_Code_Result& stImageCodeResult)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/verify/imageCode/verify";
	std::string iResponseStr;

	std::string strPara;
	strPara = "uniqueId=" + uniqueId +"&code=" + imageCode;


	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stImageCodeResult.err_code = nResult;
		stImageCodeResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stImageCodeResult.err_code = -1;
		stImageCodeResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stImageCodeResult.err_code = -1;
		stImageCodeResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();	
		return;
	}
	if (root["status"].isInt64())
	{
		stImageCodeResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stImageCodeResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stImageCodeResult.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::CheckSMSIdentifyCode(std::string& phoneNumber, std::string& messageCode, Send_SMS_Identify_Code_Result& stSendSMSIdentifyComdResult)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/verify/sms/verify";
	std::string iResponseStr;

	std::string strPara;
	strPara = "phone=" + phoneNumber + "&code=" + messageCode;
	

	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stSendSMSIdentifyComdResult.err_code = nResult;
		stSendSMSIdentifyComdResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stSendSMSIdentifyComdResult.err_code = -1;
		stSendSMSIdentifyComdResult.err_msg = QString::fromLocal8Bit("������Ϣʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stSendSMSIdentifyComdResult.err_code = -1;
		stSendSMSIdentifyComdResult.err_msg = QString::fromLocal8Bit("������Ϣʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stSendSMSIdentifyComdResult.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stSendSMSIdentifyComdResult.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stSendSMSIdentifyComdResult.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::PhoneLoginVerify(std::string& phoneNumber, std::string& messageCode, User_Base_Data& objUserBaseData)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/login/phone";
 	std::string iResponseStr;

	std::string strPara;
	strPara = "phone=" + phoneNumber + "&code=" + messageCode;
	

	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		objUserBaseData.err_code = nResult;
		objUserBaseData.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (root.isNull())
	{
		objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣʧ��").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		objUserBaseData.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		objUserBaseData.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		objUserBaseData.err_msgId = root["messageId"].asString();
	}

	if (0 == objUserBaseData.err_code && root["data"].isObject())
	{
		Json::Value data = root["data"];

		if (data["token"].isString())
		{
			objUserBaseData.token = data["token"].asString();
		}
	}
	else if (1010 == objUserBaseData.err_code  && root["data"].isObject())
	{
		//objUserBaseData.err_code = 0;
		Json::Value data = root["data"];
		if (data["users"].isArray())
		{
			Json::Value users = data["users"];
			for (int i = 0; i < users.size(); i++)
			{
				Account_Info stAccountInfo;
				if (users[i]["account"].isString())
				{
					stAccountInfo.accid = QString::fromStdString(users[i]["account"].asString());
				}

				if (users[i]["nickname"].isString())
				{
					stAccountInfo.nick = QString::fromStdString(users[i]["nickname"].asString());
				}

				if (users[i]["gmtCreate"].isInt64())
				{
					long long gmtCreate = users[i]["gmtCreate"].asInt64();
					stAccountInfo.gmtCreate = QString::number(gmtCreate);
				}

				if (users[i]["loginType"].isInt())
				{
					stAccountInfo.loginType = (Login_type)users[i]["loginType"].asInt();
				}

				if (users[i]["vipcount"].isInt())
				{
					stAccountInfo.vipCount = users[i]["vipcount"].asInt();
				}
				objUserBaseData.vecAccountInfo.push_back(stAccountInfo);
			}
		}
	}

	return;
}

void CUserDataCenterInterface::TeacherClickStartClass(std::string& strUserToken, int nCourseId, int classId, int nChapterId, PublishType type, Custom_Msg_Info& stCustomMsgInfo)
{
	char szOption[256] = { 0 };
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/start?";
	std::string iResponseStr;

	sprintf(szOption, "&courseId=%d&classId=%d&chapterId=%d&terminalType=0&clientType=1&publishType=%d", nCourseId, classId, nChapterId, type);
	std::string strPara = "token=" + strUserToken + szOption;
	//sprintf(szOption, "token=%s&courseId=%d&chapterId=%d", strUserToken,nCourseId, nChapterId);
	//std::string strPara(szOption);

	
	rikUrlStr += strPara;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCustomMsgInfo.err_code = nResult;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCustomMsgInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stCustomMsgInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stCustomMsgInfo.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::TeacherClickStopClass(std::string& strUserToken, int nCourseId, int classId, int nChapterId, Custom_Msg_Info& stCustomMsgInfo)
{
	char szOption[256] = { 0 };
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/stop";
	std::string iResponseStr;

	sprintf(szOption, "&courseId=%d&classId=%d&chapterId=%d&terminalType=0&clientType=1", nCourseId, classId, nChapterId);
	std::string strPara = "token=" + strUserToken + szOption;
	//LOG_DEBUG("CUserDataCenterInterface::TeacherClickStopClass() request post string Begin str:%s", strPara.c_str());

	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stCustomMsgInfo.err_code = nResult;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCustomMsgInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCustomMsgInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCustomMsgInfo.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::GetLiveClassroomChatroomId(std::string& strUserToken, int nCourseId, int classId, bool isTeacher, bool isTeach, int nCharpterId, User_Live_Classroom_Data &stUserLiveClassroomDate)
{
	char szOption[256] = { 0 };
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/enter";
	std::string iResponseStr;

	if (isTeacher && isTeach)
	{
		if (nCharpterId != -1)
			sprintf(szOption, "&courseId=%d&classId=%d&actionType=teach&terminalType=0&clientType=1&chapterId=%d", nCourseId, classId, nCharpterId);
		else
			sprintf(szOption, "&courseId=%d&classId=%d&actionType=teach&terminalType=0&clientType=1", nCourseId, classId);
	}
		
	else if (isTeacher && !isTeach)
		sprintf(szOption, "&courseId=%d&classId=%d&actionType=learn&terminalType=0&clientType=1", nCourseId, classId);
	else
		sprintf(szOption, "&courseId=%d&classId=%d&actionType=learn&terminalType=1&clientType=1", nCourseId, classId);
	
	std::string strPara = "token=" + strUserToken + szOption;
	

	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stUserLiveClassroomDate.err_code = nResult;
		stUserLiveClassroomDate.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stUserLiveClassroomDate.err_code = -1;
		stUserLiveClassroomDate.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stUserLiveClassroomDate.err_code = -1;
		stUserLiveClassroomDate.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stUserLiveClassroomDate.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stUserLiveClassroomDate.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stUserLiveClassroomDate.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject())
	{
		Json::Value data = root["data"];
		if (data["role"].isString())
			stUserLiveClassroomDate.stClasLiveInfo.role = data["role"].asString();
		if (data["chatroomId"].isString())
			stUserLiveClassroomDate.stClasLiveInfo.chatroomId = data["chatroomId"].asString();

		if (data["announcement"].isString())
			stUserLiveClassroomDate.stClasLiveInfo.announcement = data["announcement"].asString();

		if (data["permission"].isInt())
		{
			stUserLiveClassroomDate.permission = data["permission"].asInt();
		}

		if (data["raiseHandList"].isArray())
		{
			Json::Value raiseHandList = data["raiseHandList"];
			for (int i = 0; i < raiseHandList.size(); i++)
			{
				Raise_Hand_Info stRaiseHandInfo;
				if (raiseHandList[i]["accid"].isInt64())
				{
					int accid = raiseHandList[i]["accid"].asInt64();
					stRaiseHandInfo.accid = QString::number(accid).toStdString();
				}
				if (raiseHandList[i]["status"].isInt64())
				{
					stRaiseHandInfo.status = raiseHandList[i]["status"].asInt64();
				}

				if (raiseHandList[i]["headIcon"].isString())
				{
					stRaiseHandInfo.headIcon = raiseHandList[i]["headIcon"].asString();
				}
				stUserLiveClassroomDate.stClasLiveInfo.vecRaiseHandInfo.push_back(stRaiseHandInfo);
			}
		}
		
		if (data["managers"].isArray())
		{
			Json::Value managers = data["managers"];
			for (int i = 0; i < managers.size(); i++)
			{
				ChatRoom_Manager chatRoom_Manager;
				if (managers[i]["accid"].isInt64())
				{
					chatRoom_Manager.id = managers[i]["accid"].asInt64();
				}

				if (managers[i]["role"].isInt())
				{
					chatRoom_Manager.role = managers[i]["role"].asInt();
				}
				stUserLiveClassroomDate.managers.push_back(chatRoom_Manager);
			}
		}
		if (data["teachQualityInfo"].isArray())
		{
			Json::Value teachQualityInfo = data["teachQualityInfo"];
			for (int i = 0; i < teachQualityInfo.size(); i++)
			{
				TeachQualityInfo superInfo;
				if (teachQualityInfo[i]["nickName"].isString())
				{
					superInfo.nickName = teachQualityInfo[i]["nickName"].asString();
				}

				if (teachQualityInfo[i]["userId"].isString())
				{
					superInfo.userId = teachQualityInfo[i]["userId"].asString();
				}
				stUserLiveClassroomDate.teachQualityInfoList.push_back(superInfo);
			}
		}
		if (data["teacherInfo"].isObject())
		{
			Json::Value teacherInfo = data["teacherInfo"];
			if (teacherInfo["teacherIMAccount"].isString())
				stUserLiveClassroomDate.teacherInfo.teacherIMAccount = teacherInfo["teacherIMAccount"].asString();
			if (teacherInfo["teacherNickName"].isString())
				stUserLiveClassroomDate.teacherInfo.teacherNickName = teacherInfo["teacherNickName"].asString();
			if (teacherInfo["teacherHeadIcon"].isString())
				stUserLiveClassroomDate.teacherInfo.teacherHeadIcon = teacherInfo["teacherHeadIcon"].asString();
		}

		if (data["allowRaiseHand"].isBool())
			stUserLiveClassroomDate.stClasLiveInfo.stFunctionConfigInfo.allowRaiseHand = data["allowRaiseHand"].asBool();
		if (data["allowShowSysNotice"].isBool())
			stUserLiveClassroomDate.stClasLiveInfo.stFunctionConfigInfo.allowShowSysNotice = data["allowShowSysNotice"].asBool();
		if (data["allowJoinQQGroup"].isBool())
			stUserLiveClassroomDate.stClasLiveInfo.stFunctionConfigInfo.allowJoinQQGroup = data["allowJoinQQGroup"].asBool();
		if (data["allowSendPicture"].isBool())
			stUserLiveClassroomDate.stClasLiveInfo.stFunctionConfigInfo.allowSendPicture = data["allowSendPicture"].asBool();
		if (data["publishUser"].isInt64())
			stUserLiveClassroomDate.publishUser = data["publishUser"].asInt64();
		if (data["publishType"].isInt64())
			stUserLiveClassroomDate.publishType = data["publishType"].asInt64();
		if (data["mute"].isBool())
			stUserLiveClassroomDate.isMutx = data["mute"].asBool();
		if (data["chapterTime"].isInt())
			stUserLiveClassroomDate.chapterTime = data["chapterTime"].asInt();

		//"id": 200360,
		//	"startDate" : 1516982400000,
		//	"startTime" : 30000000,
		//	"endTime" : 34200000,
		//	"title" : "ģѹ�Ĵ󷢹��Ĵ�3",
		//	"liveStatusDicFk" : ""
		if (data["chapterInfo"].isObject())
		{
			Json::Value chapterInfo = data["chapterInfo"];
			if (chapterInfo["nextChapter"].isObject())
			{
				if (chapterInfo["nextChapter"]["id"].isInt())
				{
					stUserLiveClassroomDate.nextChapter.chapterId = chapterInfo["nextChapter"]["id"].asInt();
				}

				if (chapterInfo["nextChapter"]["startDate"].isInt64()&& chapterInfo["nextChapter"]["startTime"].isInt64()&& chapterInfo["nextChapter"]["endTime"].isInt64())
				{
					long long startDate = chapterInfo["nextChapter"]["startDate"].asInt64();
					QDateTime dateStartDate = QDateTime::fromTime_t(startDate / 1000);
					std::string qStartDate = dateStartDate.toString("yyyy/MM/dd").toStdString();

					long long startTime = chapterInfo["nextChapter"]["startTime"].asInt64();
					QDateTime dateStartTime = QDateTime::fromTime_t(startTime / 1000);
					std::string qStartTime = dateStartTime.toString("mm:ss").toStdString();

					long long endTime = chapterInfo["nextChapter"]["endTime"].asInt64();
					QDateTime dateEndTime = QDateTime::fromTime_t(endTime / 1000);
					std::string qEndTime = dateEndTime.toString("mm:ss").toStdString();

					stUserLiveClassroomDate.nextChapter.time = qStartDate + "" + qStartTime + "-" + qEndTime;
				}

				if (chapterInfo["nextChapter"]["title"].isString())
				{
					stUserLiveClassroomDate.nextChapter.title = chapterInfo["nextChapter"]["title"].asString();
				}

				if (chapterInfo["nextChapter"]["liveStatusDicFk"].isString())
				{
					stUserLiveClassroomDate.nextChapter.liveStatus = QString::fromStdString(chapterInfo["nextChapter"]["liveStatusDicFk"].asString()).toInt();
				}
			}

			if (chapterInfo["publishChapter"].isObject())
			{
				if (chapterInfo["publishChapter"]["id"].isInt())
				{
					stUserLiveClassroomDate.publishChapter.chapterId = chapterInfo["publishChapter"]["id"].asInt();
				}

				if (chapterInfo["publishChapter"]["startDate"].isInt64() && chapterInfo["publishChapter"]["startTime"].isInt64() && chapterInfo["publishChapter"]["endTime"].isInt64())
				{
					long long startDate = chapterInfo["publishChapter"]["startDate"].asInt64();
					QDateTime dateStartDate = QDateTime::fromTime_t(startDate / 1000);
					std::string qStartDate = dateStartDate.toString("yyyy/MM/dd").toStdString();

					long long startTime = chapterInfo["publishChapter"]["startTime"].asInt64();
					QDateTime dateStartTime = QDateTime::fromTime_t(startTime / 1000);
					std::string qStartTime = dateStartTime.toString("mm:ss").toStdString();

					long long endTime = chapterInfo["publishChapter"]["endTime"].asInt64();
					QDateTime dateEndTime = QDateTime::fromTime_t(endTime / 1000);
					std::string qEndTime = dateEndTime.toString("mm:ss").toStdString();

					stUserLiveClassroomDate.publishChapter.time = qStartDate + "" + qStartTime + "-" + qEndTime;
				}

				if (chapterInfo["publishChapter"]["title"].isString())
				{
					stUserLiveClassroomDate.publishChapter.title = chapterInfo["publishChapter"]["title"].asString();
				}

				if (chapterInfo["publishChapter"]["liveStatusDicFk"].isString())
				{
					stUserLiveClassroomDate.publishChapter.liveStatus = QString::fromStdString(chapterInfo["publishChapter"]["liveStatusDicFk"].asString()).toInt();
				}
			}
		}
	}
	return;
}

void CUserDataCenterInterface::GetSig(std::string& strUserToken, Sig_Info& stSig)
{
#ifdef LOCAL_ENV
	if (strUserToken == "9111534")
	{
		stSig.strSig = "eJxlkF1PgzAYhe-5FYRrY9pSyvAOxz7Q6cKGJu6mIVDaQoAGikKM-93JlozE6*d5c855vw3TNK14d7xP0rTpa031qJhlPpgWsO5uUCmZ0URTu83*QTYo2TKa5Jq1E0SOhwCYKzJjtZa5vAoehNCx8UzospJOIROH*HxuuwS7c0XyCb6sPpZhFITtWLDIF0Qs*gFkSBQnER1W-FDamjytw8fjcuvvCc47Hgr-db3pmrh6C9guHni-fU6DfRCS6KRw8d5vBl6O1ZeGYy-ZLFLL6vIL6ECXoIVL5oU*WdvJpr5MBmcFAQ-87TZ*jF-ojF18";
	}
	else if (strUserToken == "9111523")
	{
		stSig.strSig = "eJxlkF1vgjAYhe-5FYRbl9EWSsPudKIQPxJEo*yGdLTMuohdKcvqsv8*h0sk8fp53pxz3m-Ltm1nPc8eaVme2loX2kju2E*2A5yHG5RSsILqwlPsDvIvKRQvaKW56iDCIQKgrwjGay0q8S*EEEKMvJ7QsPeiC*k49C-nHgl80lfEWwcXUf6cpGN2MKvBqM7gJECTDdtWq9jQl2RUBnFGfXcfQX7GG7xzZZrsh3M1W7TBOHVn*fZQrlPTABLvokH7gaZD04Y0nC7jpXrNzbEXqcXx*guIIQk8gkm-8ydXjTjV18ngoiAQgr-d1o-1CwPYW1s_";
	}
	else if (strUserToken == "9112143")
	{
		stSig.strSig = "eJxlkFFvgjAYRd-5FYRXl-m1RQh7I4piFI0RZO6FMFpcwwa1rU5i9t-ncMlI9nzOzc29V8M0TStebh-zomhOtc50K5hlPpkWWA9-UAhOs1xnRNJ-kF0ElyzLS81kB-HIwwB9hVNWa17yX8FDCCOb9ARFq6wr6Tiyb3HiOrbbV-ihg1GwH883k62InXBBUnIBOmxLMYFThROE0-B5dfSWcbE76vRQzV6CzfzNj1TMF0ysV1N-uA9kq6afkV4348EgTF53741M7NiG88xXYa9S84-7F2iEXAc7LuAePTOpeFPfJ8NNweDBz27jy-gGUshb9g__";
	}
	else if (strUserToken == "9111526")
	{
		stSig.strSig = "eJxlkF1PgzAYhe-5FYRbjbTl22QXdS6IgWzqkkVuGkI78qqDDgqyLf53JzOxidfPc3JyzskwTdNapy83RVk2fa2YOkhhmbemhazrPyglcFYo5rT8HxSjhFawYqtEO0HiRQQhXQEuagVb*BUijLFHfE3o*DubSiaO3XPcCXw30BWoJpgtnubJQvE8DOrnQ8E-IpqRfJ9VA1k9pss7Qte9LcXrBnVddRwSCrTv6aZBsLfHPNkl8t7LqreqjB23P84-Uzser4qHZoXQMqazmVapYHf5Ans48J0gDIlGB9F20NSXyeisEBShn93Gl-ENmlJcQA__";
	}
	else if (strUserToken == "9111535")
	{
		stSig.strSig = "eJxlkEFvgjAAhe-8CsJ1y9IWC7IbOHFsw1l1c56aQos2BmigKrrsv8-hkjXZ*fteXt77tGzbdpYvizuW5-W*0lSflHDse9sBzu0fVEpyyjR1G-4Pik7JRlBWaNH0EOEAAWAqkotKy0L*CgGEELvYEFq*o31Jz*HgEnd9b*Cbitz0MB2vRwl5aD-ibL7LXg8k68rwuY2yFfLSETu*lwo-bTfdY1xCD60UPybbcJYgEpHpPuCErAvMIzR76yZhWs8np3g57mKVL27OLJmeiVGpZXn9AmLoe*7Qg0ODHkTTyrq6TgYXBYEA-Oy2vqxvv5tctw__";
	}
	else if (strUserToken == "9111140")
	{
		stSig.strSig = "eJxl0E1Pg0AQgOE7v4JwNjrL0i7bxENbSIqxoY1Q1MsGYSkbWz62i1KM-11KTSRxrs*bTGa*NF3XjeDx6TZOkrIpFFPnihv6TDfAuPnDqhIpixXDMv2HvK2E5CzOFJcDmhNqAowTkfJCiUz8BhT1Y42DU-rOhiWD9waAydQi40TsB1y74dLbOl0ObWfmR*vV3rXUj5a2hdWiWGyBrJuDFBLZ6GVVEqjn3j4LnU5Ed5TUXXJQMvcegnD3*bYpN35G3KBxMj*Jo9WzW8-vRyuVOF5-gSaITLGNER7pB5cnURbXk6FPTKBwuVv71n4Aei9cVg__";
	}
	else if (strUserToken == "9111536")
	{
		stSig.strSig = "eJxlkFtPgzAAhd-5FYRXjbZAKTXZw9jF4DYvU1GeSF3LUsUWum4Djf-dyUxs4vP3nZyc8*m4rus9zO-P6GqlttIUpqu55164HvBO-2BdC1ZQUwSa-YO8rYXmBS0N1z30EfEBsBXBuDSiFL8CgRCiILKEDXsr*pKew-AQD3AUYlsR6x4uJnejdPgit7Tt1ihTFI1l1dxWmdS0uxnl52OW7q7y6bLhbfT82g5FskgnHQNJfC0elyRILiXLVAn2yjR8imfZU8Vm8GOekfxkPxhYlUa8H7*ACOIoiHEYW3TH9UYoeZwMDooPCPjZ7Xw53yeZXVc_";
	}
	else if (strUserToken == "9111142")
	{
		stSig.strSig = "eJxlkF1vgjAYhe-5FYTrZWn57pJdVOYmDiTqiOGKFKisgrRinZpl-30Ml6zJ3tvnOTk576em67rxFq3vSVnyUydzeRXU0B90Axh3f1AIVuVE5lZf-YP0IlhPc7KVtB*h6SATAFVhFe0k27JfAcHhbFMRjlWTjyUjh-YQtzzX9lSF1SOMp2kQLoPdjrsndJbOpMExfxfJCm-AFKfrRbLyLbFp8eEFFTwN9uewfirbMCoqOHv2580kIwsc1Qfgl-NlesX1K2s9ksxinhVt9qhUSra--QI60HMtH9q*Qj9of2S8u00Gg2ICBH52a1-aN32lXD4_";
	}
	return;
#endif
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/qcloud/get-login-sign";
	rikUrlStr += "?token=";
	rikUrlStr += strUserToken;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stSig.err_code = nResult;
		stSig.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stSig.err_code = -1;
		stSig.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		stSig.err_code = -1;
		stSig.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stSig.err_code = root["status"].asUInt64();
	}
	if (root["msg"].isString()) {
		stSig.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stSig.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["loginSign"].isString())
	{
		stSig.strSig = root["data"]["loginSign"].asString();
	}
	return;
}

void CUserDataCenterInterface::CancelMute(std::string& strUserToken, int nCourseId, int classId, Mute_Info& stMute)
{
	

	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/mute/cancel";
	rikUrlStr += "?token=";
	rikUrlStr += strUserToken;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d", nCourseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stMute.err_code = nResult;
		stMute.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stMute.err_code = -1;
		stMute.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value  root;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		stMute.err_code = -1;
		stMute.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stMute.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stMute.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stMute.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["result"].isBool()) {
		stMute.isSucc = root["data"]["result"].asBool();
	}

	return;
}

void CUserDataCenterInterface::ActivateMute(std::string& strUserToken, int nCourseId, int classId, Mute_Info& stMute)
{
	

	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/mute/activate";
	rikUrlStr += "?token=";
	rikUrlStr += strUserToken;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d", nCourseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stMute.err_code = nResult;
		stMute.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stMute.err_code = -1;
		stMute.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value  root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stMute.err_code = -1;
		stMute.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();	
		return;
	}
	if (root["status"].isInt64()) {
		stMute.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stMute.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stMute.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["result"].isObject())
	{
		stMute.isSucc = root["data"]["result"].asBool();
	}
	return;
}

void CUserDataCenterInterface::HeartBeat(std::string& strUserToken, int nCourseId, int chapterId, HEART_BEAT& stHeartBeat)
{
	

	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/heartbeat";
	rikUrlStr += "?token=";
	rikUrlStr += strUserToken;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&chapterId=%d", nCourseId, chapterId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stHeartBeat.err_code = nResult;
		stHeartBeat.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stHeartBeat.err_code = -1;
		stHeartBeat.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value  root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stHeartBeat.err_code = -1;
		stHeartBeat.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	reader.parse(iResponseStr, root);
	if (root["status"].isInt64()) {
		stHeartBeat.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stHeartBeat.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stHeartBeat.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::Suggest(std::string title, std::string content, Suggest_Info& stSuggestInfo)
{
	

	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/system/suggest";
	rikUrlStr += "?title=";
	urlencode(title);
	rikUrlStr += title;
	rikUrlStr += "&content=";
	urlencode(content);
	rikUrlStr += content;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stSuggestInfo.err_code = nResult;
		stSuggestInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stSuggestInfo.err_code = -1;
		stSuggestInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value  root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stSuggestInfo.err_code = -1;
		stSuggestInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stSuggestInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stSuggestInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stSuggestInfo.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::QueryQqGroups(int courseId, Course_QQ_Info& stCourseQQInfo)
{
	
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/course/queryQqGroups";
	char szOption[256] = { 0 };
	sprintf(szOption, "?courseId=%d", courseId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCourseQQInfo.err_code = nResult;
		stCourseQQInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseQQInfo.err_code = -1;
		stCourseQQInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCourseQQInfo.err_code = -1;
		stCourseQQInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stCourseQQInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCourseQQInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCourseQQInfo.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject())
	{
		Json::Value data = root["data"];
		if (data["qqGroups"].isArray())
		{
			QQ_INFO stQQInfo;
			stCourseQQInfo.listQQInfo.clear();
			Json::Value qqGroups = data["qqGroups"];
			for (int i = 0; i < qqGroups.size(); i++)
			{
				if (qqGroups[i]["account"].isString()) {
					stQQInfo.account = qqGroups[i]["account"].asString();
				}
				if (qqGroups[i]["joinUrl"].isString()) {
					stQQInfo.joinUrl = qqGroups[i]["joinUrl"].asString();
				}
				stCourseQQInfo.listQQInfo.push_back(stQQInfo);
			}
		}
	}

	return;
}

void CUserDataCenterInterface::CheckSignupCourse(std::string& strUserToken, int courseId, Check_Signup_Course_Info& stCheckSignupCourseInfo)
{
	

	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/interaction/checkSignupCourse";
	rikUrlStr += "?token=";
	rikUrlStr += strUserToken;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d", courseId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCheckSignupCourseInfo.err_code = nResult;
		stCheckSignupCourseInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCheckSignupCourseInfo.err_code = -1;
		stCheckSignupCourseInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCheckSignupCourseInfo.err_code = -1;
		stCheckSignupCourseInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stCheckSignupCourseInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCheckSignupCourseInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCheckSignupCourseInfo.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["result"].isObject())
	{
		stCheckSignupCourseInfo.isSignup = root["data"]["result"].asBool();
		stCheckSignupCourseInfo.courseid = courseId;
	}
	return;
}

void CUserDataCenterInterface::CheckCollectCourse(std::string& strUserToken, int courseId, Check_Collect_Course_Info& stCheckCollectCourseInfo)
{
	

	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/interaction/checkCollectCourse";
	rikUrlStr += "?token=";
	rikUrlStr += strUserToken;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d", courseId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCheckCollectCourseInfo.err_code = nResult;
		stCheckCollectCourseInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCheckCollectCourseInfo.err_code = -1;
		stCheckCollectCourseInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCheckCollectCourseInfo.err_code = -1;
		stCheckCollectCourseInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stCheckCollectCourseInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stCheckCollectCourseInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stCheckCollectCourseInfo.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["result"].isInt())
	{
		stCheckCollectCourseInfo.isCollect = (bool)root["data"]["result"].asInt();
	}

	return;
}

void CUserDataCenterInterface::ReqServerRecordPublishType(std::string& strUserToken, int courseId, int publishType, Save_Publish_Type_Ret& stSavePubTypeRet)
{
	char szOption[256] = { 0 };
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/qcloud/save-publish-type";
	std::string iResponseStr;

	sprintf(szOption, "&courseId=%d&publishType=%d&terminalType=0&clientType=1", courseId, publishType);
	std::string strPara = "token=" + strUserToken + szOption;


	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stSavePubTypeRet.err_code = nResult;
		stSavePubTypeRet.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stSavePubTypeRet.err_code = -1;
		stSavePubTypeRet.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		stSavePubTypeRet.err_code = -1;
		stSavePubTypeRet.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stSavePubTypeRet.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stSavePubTypeRet.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stSavePubTypeRet.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::GetPublishTypeFromServer(int courseId, Get_Publish_Type_Ret& stGetPubTypeRet)
{
	char szOption[256] = { 0 };
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/live/qcloud/get-publish-type";
	std::string iResponseStr;

	sprintf(szOption, "courseId=%d&terminalType=0&clientType=1", courseId);
	std::string strPara = szOption;


	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stGetPubTypeRet.err_code = nResult;
		stGetPubTypeRet.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stGetPubTypeRet.err_code = -1;
		stGetPubTypeRet.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stGetPubTypeRet.err_code = -1;
		stGetPubTypeRet.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stGetPubTypeRet.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stGetPubTypeRet.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stGetPubTypeRet.err_msgId = root["messageId"].asString();
	}
	if (root.isNull())
	{
		stGetPubTypeRet.err_code = -1;
		stGetPubTypeRet.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["data"].isObject() && root["data"]["publishType"].isInt())
	{
		int type = root["data"]["publishType"].asInt();
		stGetPubTypeRet.publishType = (PublishType)type;
	}
	return;
}

void CUserDataCenterInterface::ThirdQQLogin(Third_QQ_Login &stThirdQQLogin)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/login/qq/authorizeLink";
	rikUrlStr += "?redirectUrl=";
	rikUrlStr += url + "/api/userInfo/syncAuthStatus";

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stThirdQQLogin.err_code = nResult;
		stThirdQQLogin.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stThirdQQLogin.err_code = -1;
		stThirdQQLogin.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stThirdQQLogin.err_code = -1;
		stThirdQQLogin.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stThirdQQLogin.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stThirdQQLogin.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stThirdQQLogin.err_msgId = root["messageId"].asString();
	}
	if (root.isNull())
	{
		stThirdQQLogin.err_code = -1;
		stThirdQQLogin.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["data"].isObject() && root["data"]["authorizeLink"].isString())
	{
		stThirdQQLogin.url = root["data"]["authorizeLink"].asString();
	}
	return;
}

void CUserDataCenterInterface::ThirdWeiBoLogin(Third_WeiBo_Login & stThirdWeiBoLogin)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/login/weibo/authorizeLink";
	rikUrlStr += "?redirectUrl=";
	rikUrlStr += url + "/api/userInfo/syncAuthStatus";

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stThirdWeiBoLogin.err_code = nResult;
		stThirdWeiBoLogin.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stThirdWeiBoLogin.err_code = -1;
		stThirdWeiBoLogin.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stThirdWeiBoLogin.err_code = -1;
		stThirdWeiBoLogin.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stThirdWeiBoLogin.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stThirdWeiBoLogin.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stThirdWeiBoLogin.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["authorizeLink"].isString())
	{
		stThirdWeiBoLogin.url = root["data"]["authorizeLink"].asString();
	}
	return;
}

void CUserDataCenterInterface::ThirdWeiXinLogin(Third_WeiXin_Login & stThirdWeiXinLogin)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/login/wechat/qrcode";
	rikUrlStr += "?redirectUrl=";
	rikUrlStr += url + "/api/userInfo/syncAuthStatus";

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stThirdWeiXinLogin.err_code = nResult;
		stThirdWeiXinLogin.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stThirdWeiXinLogin.err_code = -1;
		stThirdWeiXinLogin.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stThirdWeiXinLogin.err_code = -1;
		stThirdWeiXinLogin.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stThirdWeiXinLogin.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stThirdWeiXinLogin.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stThirdWeiXinLogin.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["qrcodeURI"].isString())
	{
		stThirdWeiXinLogin.url = root["data"]["qrcodeURI"].asString();
	}
	return;
}

void CUserDataCenterInterface::QueryHotCourse(Query_Hot_Course &stQueryHotCourse)
{
	char szOption[256] = { 0 };
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/recommend/queryHostCourse";
	rikUrlStr += "?limit=5";

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
	    stQueryHotCourse.err_code = nResult;
		stQueryHotCourse.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stQueryHotCourse.err_code = -1;
		stQueryHotCourse.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}


	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stQueryHotCourse.err_code = -1;
		stQueryHotCourse.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stQueryHotCourse.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stQueryHotCourse.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stQueryHotCourse.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["list"].isArray())
	{
		Json::Value list = root["data"]["list"];
		for (int i = 0; i < list.size(); i++)
		{
			Course_Link stCourseLink;
			if (list[i]["id"].isInt())
			{
				int id = list[i]["id"].asInt();
				stCourseLink.url = WWW_URL;
				stCourseLink.url += "/course/";
				stCourseLink.url += QString::number(id).toStdString();
			}
			if (list[i]["title"].isString())
			{
				stCourseLink.title = list[i]["id"].asString();
			}
			stQueryHotCourse.CourseLink.push_back(stCourseLink);
		}
	}
	return;
}

void CUserDataCenterInterface::GetUserRole(std::string & strUserToken, User_Role_Info & objUserRoleInfo)
{
#ifdef LOCAL_ENV
	if (strUserToken == "9111534" || strUserToken == "9111523")
	{
		objUserRoleInfo.role = 5703;
	}
	else if (strUserToken == "9112143" || strUserToken == "9111526")
	{
		objUserRoleInfo.role = 3000;
	}
	else if (strUserToken == "9111535" || strUserToken == "9111140")
	{
		objUserRoleInfo.role = 5702;
	}
	else
	{
		objUserRoleInfo.role = 0;
	}
	return;
#endif // LOCAL_ENV

	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/study/getRole";
	rikUrlStr += "?token=" + strUserToken;
	std::string iResponseStr;

	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		objUserRoleInfo.err_code = nResult;
		objUserRoleInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		objUserRoleInfo.err_code = -1;
		objUserRoleInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		objUserRoleInfo.err_code = -1;
		objUserRoleInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		objUserRoleInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		objUserRoleInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		objUserRoleInfo.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["role"].isInt())
	{
		objUserRoleInfo.role = root["data"]["role"].asInt();
	}
	return;
}

void CUserDataCenterInterface::GetRealtimeCourseInfo(int courseId, Course_Real_Time_Info & stCourseRealTimeInfo)
{
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/course/getRealtime";

	char szOption[256] = { 0 };
	sprintf(szOption, "?courseId=%d", courseId);
	rikUrlStr += szOption;

	std::string iResponseStr;

	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCourseRealTimeInfo.err_code = nResult;
		stCourseRealTimeInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseRealTimeInfo.err_code = -1;
		stCourseRealTimeInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCourseRealTimeInfo.err_code = -1;
		stCourseRealTimeInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCourseRealTimeInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stCourseRealTimeInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stCourseRealTimeInfo.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["courses"].isObject() && root["data"]["courses"]["collectNum"].isInt())
	{
		stCourseRealTimeInfo.collectNum = root["data"]["courses"]["collectNum"].asInt();
	}
	return;
}

void CUserDataCenterInterface::SendFlower(std::string token, bool isTeacher, int courseId, int classId, int chapter, Send_Flower_Info& stSendFlowerInfo)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/send-flower";
	rikUrlStr += "?token=";
	rikUrlStr += token;

	rikUrlStr += "&clientType=1";
	if (isTeacher)
	{
		rikUrlStr += "&terminalType=0";
	}
	else
	{
		rikUrlStr += "&terminalType=1";
	}

	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&chapterId=%d", courseId, classId, chapter);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stSendFlowerInfo.err_code = nResult;
		stSendFlowerInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stSendFlowerInfo.err_code = -1;
		stSendFlowerInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stSendFlowerInfo.err_code = -1;
		stSendFlowerInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	
	if (root["status"].isInt64())
	{
		stSendFlowerInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stSendFlowerInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stSendFlowerInfo.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::AddOrModifyUserTag(std::string token, int courseId, int classId, std::string accid, int tagValue, Custom_Msg_Info & stCustomMsgInfo)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/user-tag/add-or-modify";
	rikUrlStr += "?token=";
	rikUrlStr += token;

	rikUrlStr += "&studentId=" + accid;


	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&tagValue=%d", courseId, classId, tagValue);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCustomMsgInfo.err_code = nResult;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCustomMsgInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stCustomMsgInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stCustomMsgInfo.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::BatchQueryUserTag(std::string token, int courseId, int classId, int pageIndex, int pageSize, User_Tag_Msg & stUserTagMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/user-tag/batch-query";
	rikUrlStr += "?token=";
	rikUrlStr += token;

	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&pageIndex=%d&pageSize=%d", courseId, classId, pageIndex, pageSize);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stUserTagMsg.err_code = nResult;
		stUserTagMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stUserTagMsg.err_code = -1;
		stUserTagMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stUserTagMsg.err_code = -1;
		stUserTagMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stUserTagMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stUserTagMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stUserTagMsg.err_msgId = root["messageId"].asString();
	}


	if (root["data"].isObject() && root["data"]["userTags"].isArray())
	{
		if (root["data"]["totalPage"].isInt())
		{
			stUserTagMsg.totalSize = root["data"]["totalPage"].asInt();
		}

		Json::Value userTags = root["data"]["userTags"];
		for (int i = 0; i < userTags.size(); i++)
		{
			User_Tag_Info stUserTagInfo;

			if (userTags[i]["teacherId"].isInt64())
			{
				stUserTagInfo.teacherId = QString::number(userTags[i]["teacherId"].asInt64()).toStdString();
			}
			else if (userTags[i]["teacherId"].isString())
			{
				stUserTagInfo.teacherId = userTags[i]["teacherId"].asString();
			}
			
			if (userTags[i]["studentId"].isInt64())
			{
				stUserTagInfo.studentId = QString::number(userTags[i]["studentId"].asInt64()).toStdString();
			}
			if (userTags[i]["studentId"].isString())
			{
				stUserTagInfo.studentId = userTags[i]["studentId"].asString();
			}
			if (userTags[i]["tagValue"].isString())
			{
				stUserTagInfo.tagValue = QString::fromStdString(userTags[i]["tagValue"].asString()).toInt();
			}
			stUserTagMsg.mapUserTagInfo.insert(make_pair(stUserTagInfo.studentId, stUserTagInfo));
		}
	}
	return;
}

void CUserDataCenterInterface::SingleQueryUserTag(std::string token, int courseId, int classId, std::string accid, Single_User_Tag_Msg & stSingleUserTagMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/user-tag/single-query";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	rikUrlStr += "&studentId=" + accid;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stSingleUserTagMsg.err_code = nResult;
		stSingleUserTagMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stSingleUserTagMsg.err_code = -1;
		stSingleUserTagMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stSingleUserTagMsg.err_code = -1;
		stSingleUserTagMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stSingleUserTagMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stSingleUserTagMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stSingleUserTagMsg.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["userTag"].isObject()) {
		Json::Value userTag = root["data"]["userTag"];
		if (userTag["teacherId"].isInt())
		{
			long long teacherId = userTag["teacherId"].asInt();
			stSingleUserTagMsg.stUserTagInfo.teacherId = QString::number(teacherId).toStdString();
		}
		if (userTag["studentId"].isInt())
		{
			long long studentId = userTag["studentId"].asInt();
			stSingleUserTagMsg.stUserTagInfo.studentId = QString::number(studentId).toStdString();
		}
		if (userTag["tagValue"].isString())
		{
			stSingleUserTagMsg.stUserTagInfo.tagValue = QString::fromStdString(userTag["tagValue"].asString()).toInt();
		}
	}
	return;
}

void CUserDataCenterInterface::RaiseHand(std::string token, int courseId, int classId, Raise_Hand_Msg & stRaiseHandMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/raise-hand";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stRaiseHandMsg.err_code = nResult;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stRaiseHandMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stRaiseHandMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stRaiseHandMsg.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		Raise_Hand_Info stRaiseHandInfo;
		for (int i = 0; i < raiseHandList.size(); i++)
		{
			if (raiseHandList[i]["accid"].isInt())
			{
				int accid = raiseHandList[i]["accid"].asInt();
				stRaiseHandInfo.accid = QString::number(accid).toStdString();
			}
			if (raiseHandList[i]["nickname"].isString()) {
				stRaiseHandInfo.nickname = raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt()) {
				stRaiseHandInfo.status = raiseHandList[i]["status"].asInt();
			}
			stRaiseHandMsg.vecRaiseHandInfo.push_back(stRaiseHandInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::AgreeInChannel(std::string token, int courseId, int classId, std::string accid, Raise_Hand_Msg & stRaiseHandMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/agree-in-channel";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&studentId=%s&clientType=1&terminalType=1", courseId, classId, accid.c_str());
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stRaiseHandMsg.err_code = nResult;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stRaiseHandMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stRaiseHandMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stRaiseHandMsg.err_msgId = root["messageId"].asString();
	}
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();	
		return;
	}
	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		for (int i = 0; i < raiseHandList.size(); i++)
		{
			Raise_Hand_Info stRaiseHandInfo;
			if (raiseHandList[i]["accid"].isInt()) {
				int accid = raiseHandList[i]["accid"].asInt();
				stRaiseHandInfo.accid = QString::number(accid).toStdString();
			}
			if (raiseHandList[i]["nickname"].isString()) {
				stRaiseHandInfo.nickname = raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt()) {
				stRaiseHandInfo.status = raiseHandList[i]["status"].asInt();
			}
			stRaiseHandMsg.vecRaiseHandInfo.push_back(stRaiseHandInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::OutChannel(std::string token, int courseId, int classId, Raise_Hand_Msg & stRaiseHandMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/out-channel";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stRaiseHandMsg.err_code = nResult;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stRaiseHandMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stRaiseHandMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stRaiseHandMsg.err_msgId = root["messageId"].asString();
	}
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{			
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		for (int i = 0; i < raiseHandList.size(); i++)
		{
			Raise_Hand_Info stRaiseHandInfo;
			if (raiseHandList[i]["accid"].isInt()) {
				int accid = raiseHandList[i]["accid"].asInt();
				stRaiseHandInfo.accid = QString::number(accid).toStdString();
			}
			if (raiseHandList[i]["nickname"].isString()) {
				stRaiseHandInfo.nickname = raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt()) {
				stRaiseHandInfo.status = raiseHandList[i]["status"].asInt();
			}
			stRaiseHandMsg.vecRaiseHandInfo.push_back(stRaiseHandInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::KickStudent(std::string token, int courseId, int classId, std::string accid, Raise_Hand_Msg & stRaiseHandMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/kick-student";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&studentId=%s&clientType=1&terminalType=1", courseId, classId, accid.c_str());
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stRaiseHandMsg.err_code = nResult;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stRaiseHandMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stRaiseHandMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stRaiseHandMsg.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		for (int i = 0; i < raiseHandList.size(); i++)
		{
			Raise_Hand_Info stRaiseHandInfo;
			if (raiseHandList[i]["accid"].isInt()) {
				int accid = raiseHandList[i]["accid"].asInt();
				stRaiseHandInfo.accid = QString::number(accid).toStdString();
			}
			if (raiseHandList[i]["nickname"].isString()) {
				stRaiseHandInfo.nickname = raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt()) {
				stRaiseHandInfo.status = raiseHandList[i]["status"].asInt();
			}
			stRaiseHandMsg.vecRaiseHandInfo.push_back(stRaiseHandInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::InviteStudent(std::string token, int courseId, int classId, std::string accid, Raise_Hand_Msg & stRaiseHandMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/invite-student";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&studentId=%s&clientType=1&terminalType=1", courseId, classId, accid.c_str());
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stRaiseHandMsg.err_code = nResult;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stRaiseHandMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stRaiseHandMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stRaiseHandMsg.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{	
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		for (int i = 0; i < raiseHandList.size(); i++)
		{
			Raise_Hand_Info stRaiseHandInfo;
			if (raiseHandList[i]["accid"].isInt()) {
				int accid = raiseHandList[i]["accid"].asInt();
				stRaiseHandInfo.accid = QString::number(accid).toStdString();
			}
			if (raiseHandList[i]["nickname"].isString()) {
				stRaiseHandInfo.nickname = raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt()) {
				stRaiseHandInfo.status = raiseHandList[i]["status"].asInt();
			}
			stRaiseHandMsg.vecRaiseHandInfo.push_back(stRaiseHandInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::InChannel(std::string token, int courseId, int classId, Raise_Hand_Msg& stRaiseHandMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/in-channel";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stRaiseHandMsg.err_code = nResult;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stRaiseHandMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stRaiseHandMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stRaiseHandMsg.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		for (int i = 0; i < raiseHandList.size(); i++)
		{
			Raise_Hand_Info stRaiseHandInfo;
			if (raiseHandList[i]["accid"].isInt()) {
				int accid = raiseHandList[i]["accid"].asInt();
				stRaiseHandInfo.accid = QString::number(accid).toStdString();
			}
			if (raiseHandList[i]["nickname"].isString()) {
				stRaiseHandInfo.nickname = raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt()) {
				stRaiseHandInfo.status = raiseHandList[i]["status"].asInt();
			}
			stRaiseHandMsg.vecRaiseHandInfo.push_back(stRaiseHandInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::SendFlower(std::string token, int courseId, int classId, std::string nickname, Custom_Msg_Info & stCustomMsgInfo)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/send-flower";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&nickname=%s&clientType=1&terminalType=1", courseId, classId, nickname.c_str());
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCustomMsgInfo.err_code = nResult;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCustomMsgInfo.err_code = -1;
		stCustomMsgInfo.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCustomMsgInfo.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stCustomMsgInfo.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stCustomMsgInfo.err_msgId = root["messageId"].asString();
	}

}

void CUserDataCenterInterface::GetOthersInfo(std::string token, int courseId, int classId, std::string accid, User_Base_Data & stUserBaseData)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/get-others-info";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	if (courseId == -1)
	{
		sprintf(szOption, "&userId=%s&clientType=1&terminalType=1", accid.c_str());
	}
	else
	{
		sprintf(szOption, "&courseId=%d&classId=%d&userId=%s&clientType=1&terminalType=1", courseId, classId, accid.c_str());
	}
	
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stUserBaseData.err_code = nResult;
		stUserBaseData.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stUserBaseData.err_code = -1;
		stUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (root.isNull())
	{
		stUserBaseData.err_code = -1;
		stUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		stUserBaseData.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		stUserBaseData.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		stUserBaseData.err_msgId = root["messageId"].asString();
	}

	if (0 != stUserBaseData.err_code)
	{
		return;
	}

	if (root["data"].isObject())
	{
		Json::Value data = root["data"];
		if (data["account"].isString())
		{
			stUserBaseData.account = data["account"].asString();
		}
		if (data["nickname"].isString())
		{
			stUserBaseData.nick = data["nickname"].asString();
		}
		if (data["uid"].isString())
		{
			std::string str=data["uid"].asString();
			stUserBaseData.userid = atoll(str.c_str());
		}

		if (data["headImg"].isString())
		{
			stUserBaseData.ico = data["headImg"].asString();
		}

		if (data["qq"].isString())
		{
			stUserBaseData.qq = data["qq"].asString();
		}

		if (data["email"].isString())
		{
			stUserBaseData.email = data["email"].asString();
		}

		if (data["phone"].isString())
		{
			stUserBaseData.phone = data["phone"].asString();
		}
	}
	return;
}

void CUserDataCenterInterface::AddListenRecord(std::string token, int courseId, int classId, bool isLive, Custom_MsgV2_Info& stCustom_Msg_Info)
{
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/course/addListenRecord";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	if (isLive)
	{
		sprintf(szOption, "&courseId=%d&classIdFk=%d&liveType=8010&platformType=8112", courseId, classId);
	}
	else
	{
		sprintf(szOption, "&courseId=%d&classIdFk=%d&liveType=8011&platformType=8112", courseId, classId);
	}

	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCustom_Msg_Info.err_code = nResult;
		stCustom_Msg_Info.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}
	if (iResponseStr.empty())
	{
		stCustom_Msg_Info.err_code = -1;
		stCustom_Msg_Info.err_msg = QString::fromLocal8Bit("http(s)������ϢΪ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (!root.isNull())
	{
		if (root["status"].isInt64())
		{
			stCustom_Msg_Info.err_code = root["status"].asInt64();
		}

		if (root["msg"].isString())
		{
			stCustom_Msg_Info.err_msg = root["msg"].asString();
		}
		if (root["messageId"].isString())
		{
			stCustom_Msg_Info.err_msgId = root["messageId"].asString();
		}
	}
	else
	{
		stCustom_Msg_Info.err_code = -1;
		stCustom_Msg_Info.err_msg = QString::fromLocal8Bit("json����ʧ��").toStdString();
	}
	return;
}

void CUserDataCenterInterface::QueryListenRecord(std::string token, int pageIndex, int pageSize, History_Msg& stCourseResult)
{
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/course/queryListenRecord";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };

	sprintf(szOption, "&pageIndex=%d&pageSize=%d", pageIndex, pageSize);

	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCourseResult.err_code = nResult;
		stCourseResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}
	if (iResponseStr.empty())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("http(s)������ϢΪ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (!root.isNull())
	{
		if (root["status"].isInt64())
		{
			stCourseResult.err_code = root["status"].asInt64();
		}

		if (root["msg"].isString())
		{
			stCourseResult.err_msg = root["msg"].asString();
		}
		if (root["messageId"].isString())
		{
			stCourseResult.err_msgId = root["messageId"].asString();
		}
		if (0 != stCourseResult.err_code)
		{
			return;
		}


		if (root["data"].isObject())
		{
			Json::Value data = root["data"];


			if (data["courses"].isArray())
			{

				Json::Value courses = data["courses"];

				stCourseResult.count = courses.size();

				for (int i = 0; i < courses.size(); i++)
				{
					History_Info stCourseInfo;
					if (courses[i]["courseId"].isInt())
					{
						stCourseInfo.courseId = courses[i]["courseId"].asInt();
					}

					if (courses[i]["classId"].isInt())
					{
						stCourseInfo.classId = courses[i]["classId"].asInt();
					}

					if (courses[i]["period"].isInt())
					{
						stCourseInfo.period = courses[i]["period"].asInt();
					}

					if (courses[i]["title"].isString())
					{
						stCourseInfo.title = courses[i]["title"].asString();
					}

					if (courses[i]["cover"].isString())
					{
						stCourseInfo.cover = m_Realm + courses[i]["cover"].asString();
					}
					if (courses[i]["courseType"].isInt())
					{
						stCourseInfo.courseType = courses[i]["courseType"].asInt();
					}

					if (courses[i]["mainTeacher"].isString())
					{
						stCourseInfo.mainTeacher = courses[i]["mainTeacher"].asString();
					}

					stCourseResult.vectorHistoryMsg.push_back(stCourseInfo);
				}
			}
		}
	}
	else
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("json����ʧ��").toStdString();
	}

	return;
}

void CUserDataCenterInterface::UpdateFunctionConfig(std::string token, int courseId, int classId, ClassFunctionCode code, Function_Config_Msg & stFunctionConfigMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/course/update-function-config";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&functionCode=%d&clientType=1&terminalType=1", courseId, classId, (int)code);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stFunctionConfigMsg.err_code = nResult;
		stFunctionConfigMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stFunctionConfigMsg.err_code = -1;
		stFunctionConfigMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stFunctionConfigMsg.err_code = -1;
		stFunctionConfigMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stFunctionConfigMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stFunctionConfigMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stFunctionConfigMsg.err_msgId = root["messageId"].asString();
	}
	
	if (0 != stFunctionConfigMsg.err_code)
	{
		return;
	}
	
	if (root["data"].isObject())
	{
		Json::Value data = root["data"];
		if (data["allowRaiseHand"].isBool()) {
			stFunctionConfigMsg.stFunctionConfigInfo.allowRaiseHand = data["allowRaiseHand"].asBool();
		}
		if (data["allowShowSysNotice"].isBool()) {
			stFunctionConfigMsg.stFunctionConfigInfo.allowShowSysNotice = data["allowShowSysNotice"].asBool();
		}
		if (data["allowJoinQQGroup"].isBool()) {
			stFunctionConfigMsg.stFunctionConfigInfo.allowJoinQQGroup = data["allowJoinQQGroup"].asBool();
		}
		if (data["allowSendPicture"].isBool()) {
			stFunctionConfigMsg.stFunctionConfigInfo.allowSendPicture = data["allowSendPicture"].asBool();
		}
	}
	return;
}

void CUserDataCenterInterface::StudentSendPushFail(std::string token, int courseId, int classId, StudentWheat_Result&result)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/push-stream-fail";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		result.result = 0;
		result.err_code = nResult;
		result.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}
	if (iResponseStr.empty())
	{
		result.err_code = -1;
		result.err_msg = QString::fromLocal8Bit("������Ϣʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		result.err_code = -1;
		result.err_msg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		result.result = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		result.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		result.err_msgId = root["messageId"].asString();
	}

	if (0 != result.err_code)
	{
		return;
	}

	if (root["accid"].isString())
	{
		root["accid"].asString();
	}
	if (root["nickname"].isString())
	{
		root["nickname"].asString();
	}
	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		for (int i = 0; root["data"]["raiseHandList"].size(); i++)
		{
			if (raiseHandList[i]["accid"].isString())
			{
				raiseHandList[i]["accid"].asString();
			}
			if (raiseHandList[i]["nickname"].isString())
			{
				raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt())
			{
				raiseHandList[i]["status"].asString();
			}
		}
	}
}

void CUserDataCenterInterface::StudentAgreeWheatInvite(std::string token, int courseId, int classId, StudentWheat_Result&result)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/accept-invite";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		result.err_code = nResult;
		result.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}
	if (iResponseStr.empty())
	{
		result.err_code = -1;
		result.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		result.err_code = -1;
		result.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		result.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		result.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		result.err_msgId = root["messageId"].asString();
	}
}

void CUserDataCenterInterface::StudentRefuseWheatInvite(std::string token, int courseId, int classId, StudentWheat_Result&result)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/reject-invite";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		result.err_code = nResult;
		result.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}
	if (iResponseStr.empty())
	{
		result.result = 0;
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		result.err_code = nResult;
		result.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		result.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		result.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		result.err_msgId = root["messageId"].asString();
	}

}

void CUserDataCenterInterface::PhoneIsAvailable(std::string phone, Phone_Available_Msg & stPhoneAvailableMsg)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/verify/available/phone";
	std::string iResponseStr;

	std::string strPara;
	strPara = "phone=" + phone;
	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		stPhoneAvailableMsg.err_code = nResult;
		stPhoneAvailableMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stPhoneAvailableMsg.err_code = -1;
		stPhoneAvailableMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stPhoneAvailableMsg.err_code = -1;
		stPhoneAvailableMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();	
		return;
	}
	if (root["status"].isInt64())
	{
		stPhoneAvailableMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stPhoneAvailableMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stPhoneAvailableMsg.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["result"].isBool())
	{
		stPhoneAvailableMsg.isAvailable = root["data"]["result"].asBool();
	}
	return;
}

void CUserDataCenterInterface::QueryByPhone(std::string phone, Query_Phone_Msg& stQueryPhoneMsg)
{
	char szOption[256] = { 0 };
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/userInfo/query-by-phone";
	rikUrlStr += "?phone=" + phone;
	std::string iResponseStr;

	//LOG_DEBUG("CUserDataCenterInterface::QueryByPhone()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	//	LOG_DEBUG("CUserDataCenterInterface::QueryByPhone()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		stQueryPhoneMsg.err_code = nResult;
		stQueryPhoneMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stQueryPhoneMsg.err_code = -1;
		stQueryPhoneMsg.err_msg = QString::fromLocal8Bit("������Ϣʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		stQueryPhoneMsg.err_code = -1;
		stQueryPhoneMsg.err_msg = QString::fromLocal8Bit("������Ϣʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stQueryPhoneMsg.err_code=root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stQueryPhoneMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stQueryPhoneMsg.err_msgId = root["messageId"].asString();
	}
	if (0 != stQueryPhoneMsg.err_code)
	{
		return;
	}
	if (root["data"].isObject() && root["data"]["users"].isArray())
	{			
		Json::Value users = root["data"]["users"];
		for (int i = 0; i < users.size(); i++)
		{
				
			Account_Info vecAccountInfo;
			if (users[i]["account"].isString())
			{
				vecAccountInfo.accid = QString::fromStdString(users[i]["account"].asString());
			}
			if (users[i]["nickname"].isString())
			{
				vecAccountInfo.nick = QString::fromStdString(users[i]["nickname"].asString());
			}
			if (users[i]["gmtCreate"].isInt64())
			{
				long long gmtCreate = users[i]["gmtCreate"].asInt64();
				vecAccountInfo.gmtCreate = QString::number(gmtCreate);
			}
			if (users[i]["loginType"].isInt())
			{
				vecAccountInfo.loginType = (Login_type)users[i]["loginType"].asInt();
			}
			if (users[i]["vipcount"].isInt64())
			{
				vecAccountInfo.vipCount = users[i]["vipcount"].asInt64();
			}
			stQueryPhoneMsg.vecAccountInfo.push_back(vecAccountInfo);
		}
	}
	return;
}

void CUserDataCenterInterface::QQBindPhone(std::string phone, std::string code, std::string state, std::string password, std::string nickname, Third_Bind_Msg & stThirdBindMsg)
{
	char szOption[256] = { 0 };
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/login/qq/bindphone";
	rikUrlStr += "?phone=" + phone;
	rikUrlStr += "&code=" + code;
	rikUrlStr += "&state=" + state;
	rikUrlStr += "&password=" + password;
	rikUrlStr += "&nickname=" + nickname;
	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::QQBindPhone()requestURL str:%s", rikUrlStr.c_str());

	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::QQBindPhone()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		stThirdBindMsg.err_code = nResult;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stThirdBindMsg.err_code = -1;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		stThirdBindMsg.err_code = -1;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stThirdBindMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stThirdBindMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stThirdBindMsg.err_msgId = root["messageId"].asString();
	}
	if (root["data"].isObject() && root["data"]["token"].isString())
	{
		stThirdBindMsg.token = root["data"]["token"].asString();
	}
	return;
}

void CUserDataCenterInterface::WeiBoBindPhone(std::string phone, std::string code, std::string state, std::string password, std::string nickname, Third_Bind_Msg & stThirdBindMsg)
{
	char szOption[256] = { 0 };
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/login/weibo/bindphone";
	rikUrlStr += "?phone=" + phone;
	rikUrlStr += "&code=" + code;
	rikUrlStr += "&state=" + state;
	rikUrlStr += "&password=" + password;
	rikUrlStr += "&nickname=" + nickname;
	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::QQBindPhone()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::WeiXinBindPhone()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		stThirdBindMsg.err_code = nResult;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stThirdBindMsg.err_code = -1;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stThirdBindMsg.err_code = -1;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stThirdBindMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stThirdBindMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stThirdBindMsg.err_msgId = root["messageId"].asString();
	}
	if (0 != stThirdBindMsg.err_code)
	{
		return;
	}
	if (root["data"].isObject() && root["data"]["token"].isString())
	{
		stThirdBindMsg.token = root["data"]["token"].asString();
	}
	return;
}

void CUserDataCenterInterface::WeiXinBindPhone(std::string phone, std::string code, std::string state, std::string password, std::string nickname, Third_Bind_Msg & stThirdBindMsg)
{
	char szOption[256] = { 0 };
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/login/wechat/bindphone";
	rikUrlStr += "?phone=" + phone;
	rikUrlStr += "&code=" + code;
	rikUrlStr += "&state=" + state;
	rikUrlStr += "&password=" + password;
	rikUrlStr += "&nickname=" + nickname;
	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::QQBindPhone()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::WeiXinBindPhone()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		stThirdBindMsg.err_code = nResult;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stThirdBindMsg.err_code = -1;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		stThirdBindMsg.err_code = -1;
		stThirdBindMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64()) {
		stThirdBindMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		stThirdBindMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString()) {
		stThirdBindMsg.err_msgId = root["messageId"].asString();
	}
	if (0 != stThirdBindMsg.err_code)
	{
		return;
	}
	if (root["data"].isObject() && root["data"]["token"].isString())
	{
		stThirdBindMsg.token = root["data"]["token"].asString();
	}
	return;
}

void CUserDataCenterInterface::SelectPhoneAccountLogin(std::string phone, std::string phoneCode, std::string platformType, std::string account, std::string nick, std::string passWord, User_Base_Data & objUserBaseData)
{
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/login/phone";
	std::string iResponseStr;
	urlencode(passWord);
	std::string strPara;
	if (account.empty())
	{
		strPara = "phone=" + phone + "&code=" + phoneCode + "&password=" + passWord + "&nickname=" + nick;
	}
	else
	{
		if (platformType.empty())
		{
			strPara = "phone=" + phone + "&code=" + phoneCode + "&account=" + account + "&nickname=" + nick;
		}
		else
		{
			strPara = "phone=" + phone + "&code=" + phoneCode + "&platformType=" + platformType + "&account=" + account + "&nickname=" + nick;
		}

	}
	int nResult = CHttpClient::GetInstance()->Posts(rikUrlStr, strPara, iResponseStr);
	if (0 != nResult)
	{
		objUserBaseData.err_code = nResult;
		objUserBaseData.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (root.isNull())
	{
		objUserBaseData.err_code = -1;
		objUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		objUserBaseData.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		objUserBaseData.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		objUserBaseData.err_msgId = root["messageId"].asString();
	}

	if (0 == objUserBaseData.err_code && root["data"].isObject() && root["data"]["token"].isString())
	{
		objUserBaseData.token = root["data"]["token"].asString();
	}

	return;
}

void CUserDataCenterInterface::QueryCurrentAccountBindingStatus(std::string token, Query_Account_Msg & lqueryAccountMsg)
{
	char szOption[256] = { 0 };
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/userInfo/query-phone-status";
	rikUrlStr += "?token=" + token;
	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::QueryCurrentAccountBindingStatus()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::QueryCurrentAccountBindingStatus()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		lqueryAccountMsg.err_code = nResult;
		lqueryAccountMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		lqueryAccountMsg.err_code = -1;
		lqueryAccountMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		lqueryAccountMsg.err_code = -1;
		lqueryAccountMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();	
		return;
	}
	if (root["status"].isInt64())
	{
		lqueryAccountMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		lqueryAccountMsg.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		lqueryAccountMsg.err_msgId = root["messageId"].asString();
	}

	if (0 != lqueryAccountMsg.err_code)
	{
		return;
	}

	if (root["data"].isObject())
	{
		Json::Value data = root["data"];
		
		if (data["count"].isInt64()) 
		{
			lqueryAccountMsg.count = data["count"].asInt64();
		}
		
		if (data["users"].isObject())
		{
			Json::Value users = data["users"];

			for (int i = 0; i < users.size();i++)
			{
				if (users[i]["phone"].isString())
				{
					lqueryAccountMsg.phone = users[i]["phone"].asString();
				}
			}
		}
	}
	return;
}

void CUserDataCenterInterface::OldBindPhone(std::string phoneCode, std::string phone, std::string token, OldAccount_Bind_Msg & lOldAccountBindMsg)
{
	char szOption[256] = { 0 };
	std::string url = AUTH_URL;
	std::string rikUrlStr = url + "/api/bind/phone";
	rikUrlStr += "?code=" + phoneCode;
	rikUrlStr += "&phone=" + phone;
	rikUrlStr += "&token=" + token;
	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()backData str:%s", iResponseStr.c_str());

	if (0 != nResult)
	{
		lOldAccountBindMsg.err_code = nResult;
		lOldAccountBindMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		lOldAccountBindMsg.err_code = -1;
		lOldAccountBindMsg.err_msg = QString::fromLocal8Bit("���ش�����Ϣ").toStdString();
		return;
	}
	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr,root);
	if (root.isNull())
	{
		lOldAccountBindMsg.err_code = -1;
		lOldAccountBindMsg.err_msg = QString::fromLocal8Bit("���ش�����Ϣ").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		lOldAccountBindMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString()) {
		lOldAccountBindMsg.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		lOldAccountBindMsg.err_msgId = root["messageId"].asString();
	}
	return;
}

void CUserDataCenterInterface::GetTeacherClassDetail(std::string token,int courseId, int classId, Course_Detail_MSG & stCourseDetailMsg)
{
	std::string url = WWW_URL;
	url += "/api/course/getByTeacher";
	char szOption[256] = { 0 };
	sprintf(szOption, "?courseId=%d&classId=%d", courseId, classId);
	url += szOption;
	url += "&token=" + token;

	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(url, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		stCourseDetailMsg.errCode = nResult;
		stCourseDetailMsg.errMsg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::QQBindPhone(): post data error (%s)", CHttpClient::GetInstance()->GetErrorStr(nResult));
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseDetailMsg.errCode = -1;
		stCourseDetailMsg.errMsg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::QQBindPhone(): request return string is empty!");
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (!root.isNull())
	{
		if (root["status"].isInt64())
		{
			stCourseDetailMsg.errCode = root["status"].asInt64();
		}

		if (root["msg"].isString())
		{
			stCourseDetailMsg.errMsg = root["msg"].asString();
		}
		if (root["messageId"].isString())
		{
			stCourseDetailMsg.err_msgId = root["messageId"].asString();
		}

		if (0 != stCourseDetailMsg.errCode)
		{
			return;
		}

		if (root["data"].isObject())
		{
			Json::Value data = root["data"];

			if (data["course"].isObject())
			{
				Json::Value course = data["course"];
				Course_Info& stCourseInfo = stCourseDetailMsg.stCourseInfo;
				if (course["id"].isInt())
				{
					stCourseInfo.id = course["id"].asInt();
					stCourseInfo.classId = classId;
				}

				if (course["title"].isString())
				{
					stCourseInfo.title = course["title"].asString();
				}

				if (course["cover"].isString())
				{
					stCourseInfo.cover = course["cover"].asString();
					stCourseInfo.cover = m_Realm + stCourseInfo.cover;
				}

				if (course["typeDicFk"].isInt())
				{
					stCourseInfo.courseType = course["typeDicFk"].asInt();
				}

				if (course["roleType"].isString())
				{
					stCourseInfo.role = atoi(course["roleType"].asString().c_str());
				}

				if (course["liveStatusDicFk"].isString())
				{
					stCourseInfo.liveStatus = QString::fromStdString(course["liveStatusDicFk"].asString()).toInt();
				}

				if (course["price"].isString())
				{
					stCourseInfo.price = course["price"].asString();
				}

				if (course["schoolName"].isString())
				{
					stCourseInfo.schoolName = course["schoolName"].asString();
				}

				if (course["unshelveDicFk"].isInt())
				{
					stCourseInfo.unshelveDicFk = course["unshelveDicFk"].asInt();
				}


				if (course["shangkeStatusDicFk"].isInt())
				{
					stCourseInfo.shangkeStatusDicFk = course["shangkeStatusDicFk"].asInt();
				}


				if (course["startTimeMills"].isInt64())
				{
					long long ltime = course["startTimeMills"].asInt64();
					QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
					stCourseInfo.nextChapterTime = dateTime.toString("yyyy-MM-dd hh:mm:ss").toStdString();
				}
				
				if (course["endChapterNumber"].isInt())
				{
					stCourseInfo.endChapterNumber = course["endChapterNumber"].asInt();
				}

				if (course["chapterNum"].isInt())
				{
					stCourseInfo.chapterNumber = course["chapterNum"].asInt();
				}

				if (course["mainTeacher"].isString())
				{
					stCourseInfo.teacherName = course["mainTeacher"].asString();
				}


				if (course["courseChapter"].isArray())
				{
					Json::Value chapter = course["courseChapter"];

					for (int i = 0; i < chapter.size(); i++)
					{
						User_Chapter_Info stUserChapterInfo;
						if (chapter[i]["createTime"].isInt64())
						{
							long long ltime = chapter[i]["createTime"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.createTime = dateTime.toString("yyyy-MM-dd").toStdString();
						}

						if (chapter[i]["startDate"].isInt64())
						{
							long long ltime = chapter[i]["startDate"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.startDate = dateTime.toString("yyyy-MM-dd").toStdString();
						}

						if (chapter[i]["courseIdFk"].isInt())
						{
							stUserChapterInfo.courseIdFk = chapter[i]["courseIdFk"].asInt();
						}

						if (chapter[i]["endTime"].isInt64())
						{
							long long ltime = chapter[i]["endTime"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.endTime = dateTime.toString("hh:mm").toStdString();
						}


						if (chapter[i]["startTime"].isInt64())
						{
							long long ltime = chapter[i]["startTime"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.startTime = dateTime.toString("hh:mm").toStdString();
						}

						if (chapter[i]["id"].isInt())
						{
							stUserChapterInfo.id = chapter[i]["id"].asInt();
						}



						if (chapter[i]["title"].isString())
						{
							stUserChapterInfo.title = chapter[i]["title"].asString();
						}

						if (chapter[i]["liveStatusDicFk"].isInt())
						{
							stUserChapterInfo.liveStatusDickFk = chapter[i]["liveStatusDicFk"].asInt();
						}


						if (chapter[i]["userIdFk"].isString())
						{
							stUserChapterInfo.userIdFk = chapter[i]["userIdFk"].asString();
						}

						stUserChapterInfo.courseTitle = stCourseInfo.title;

						if (chapter[i]["hideFlag"].isInt())
						{
							stUserChapterInfo.isHideFlag = chapter[i]["hideFlag"].asInt();
						}

						if (chapter[i]["vedios"].isArray())
						{
							Json::Value video = chapter[i]["vedios"];
							for (int j = 0; j < video.size(); j++)
							{
								Video_Info stVideoInfo;
								if (video[j]["id"].isInt())
								{
									stVideoInfo.id = video[j]["id"].asInt();
								}

								if (video[j]["courseId"].isInt())
								{
									stVideoInfo.courseId = video[j]["courseId"].asInt();
								}

								if (video[j]["chapterId"].isInt())
								{
									stVideoInfo.chapterId = video[j]["chapterId"].asInt();
								}

								if (video[j]["vedioName"].isString())
								{
									stVideoInfo.vedioName = video[j]["vedioName"].asString();
								}

								if (video[j]["covers"].isString())
								{
									stVideoInfo.covers = video[j]["covers"].asString();
									if (!stVideoInfo.covers.empty())
										stVideoInfo.covers = m_Realm + stVideoInfo.covers;
								}

								if (video[j]["startTime"].isInt64())
								{
									long long ltime = video[j]["startTime"].asInt64();
									QDateTime dateTime = QDateTime::fromTime_t(ltime / 100);
									stUserChapterInfo.startTime = dateTime.toString("hh:mm:ss").toStdString();
								}

								if (video[j]["type"].isString())
								{
									stVideoInfo.type = video[j]["type"].asString();
								}

								if (video[j]["playUrlLd"].isString())
								{
									stVideoInfo.playUrlLd = video[j]["playUrlLd"].asString();
								}

								if (video[j]["playUrlSd"].isString())
								{
									stVideoInfo.playUrlSd = video[j]["playUrlSd"].asString();
								}

								if (video[j]["playUrlHd"].isString())
								{
									stVideoInfo.playUrlHd = video[j]["playUrlHd"].asString();
								}

								if (video[j]["ossUrl"].isString())
								{
									stVideoInfo.ossUrl = video[j]["ossUrl"].asString();
								}

								if (video[j]["ctreateTime"].isString())
								{
									stVideoInfo.ctreateTime = video[j]["ctreateTime"].asString();
								}

								if (video[j]["modifyTime"].isString())
								{
									stVideoInfo.modifyTime = video[j]["modifyTime"].asString();
								}
								stUserChapterInfo.vedios.push_back(stVideoInfo);

							}
							
						}
						stCourseDetailMsg.vecChapterInfo.push_back(stUserChapterInfo);
					}
				}
			}
		}
	}
	else
	{
		stCourseDetailMsg.errCode = -1;
		stCourseDetailMsg.errMsg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
	}
	return;
}

void CUserDataCenterInterface::GetStudentClassDetail(std::string token, int courseId, Course_Detail_MSG & stCourseDetailMsg)
{
	std::string url = WWW_URL;
	url += "/api/course/getByStudent";
	url += "?token=" + token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d", courseId);
	url += szOption;

	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(url, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		stCourseDetailMsg.errCode = nResult;
		stCourseDetailMsg.errMsg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::QQBindPhone(): post data error (%s)", CHttpClient::GetInstance()->GetErrorStr(nResult));
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseDetailMsg.errCode = -1;
		stCourseDetailMsg.errMsg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::QQBindPhone(): request return string is empty!");
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (!root.isNull())
	{
		if (root["status"].isInt64())
		{
			stCourseDetailMsg.errCode = root["status"].asInt64();
		}

		if (root["msg"].isString())
		{
			stCourseDetailMsg.errMsg = root["msg"].asString();
		}
		if (root["messageId"].isString())
		{
			stCourseDetailMsg.err_msgId = root["messageId"].asString();
		}
		if (0 != stCourseDetailMsg.errCode)
		{
			return;
		}

		if (root["data"].isObject())
		{
			Json::Value data = root["data"];

			if (data["course"].isObject())
			{
				Json::Value course = data["course"];
				Course_Info& stCourseInfo = stCourseDetailMsg.stCourseInfo;
				if (course["id"].isInt())
				{
					stCourseInfo.id = course["id"].asInt();
				}

				if (course["classId"].isInt())
				{
					stCourseInfo.classId = course["classId"].asInt();
				}

				if (course["period"].isInt())
				{
					stCourseInfo.period = course["period"].asInt();
				}

				if (course["buttonStatus"].isInt())
				{
					stCourseInfo.buttonStatus = course["buttonStatus"].asInt();
				}
				
				if (course["title"].isString())
				{
					stCourseInfo.title = course["title"].asString();
				}

				if (course["cover"].isString())
				{
					stCourseInfo.cover = course["cover"].asString();
					stCourseInfo.cover = m_Realm + stCourseInfo.cover;
				}

				if (course["typeDicFk"].isInt())
				{
					stCourseInfo.courseType = course["typeDicFk"].asInt();
				}

				stCourseInfo.role = 5703;

				if (course["liveStatusDicFk"].isString())
				{
					stCourseInfo.liveStatus = QString::fromStdString(course["liveStatusDicFk"].asString()).toInt();
				}		

				if (course["price"].isString())
				{
					stCourseInfo.price = course["price"].asString();
				}

				if (course["schoolName"].isString())
				{
					stCourseInfo.schoolName = course["schoolName"].asString();
				}

				if (course["unshelveDicFk"].isInt())
				{
					stCourseInfo.unshelveDicFk = course["unshelveDicFk"].asInt();
				}


				if (course["shangkeStatusDicFk"].isInt())
				{
					stCourseInfo.shangkeStatusDicFk = course["shangkeStatusDicFk"].asInt();
				}


				if (course["startTimeMills"].isInt64())
				{
					long long ltime = course["startTimeMills"].asInt64();
					QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
					stCourseInfo.nextChapterTime = dateTime.toString("yyyy-MM-dd hh:mm:ss").toStdString();
				}

				if (course["endChapterNumber"].isInt())
				{
					stCourseInfo.endChapterNumber = course["endChapterNumber"].asInt();
				}

				if (course["chapterNum"].isInt())
				{
					stCourseInfo.chapterNumber = course["chapterNum"].asInt();
				}

				if (course["mainTeacher"].isString())
				{
					stCourseInfo.teacherName = course["mainTeacher"].asString();
				}
				if (course["supervisoryTelephone"].isString())
				{
					stCourseInfo.supervisoryTelephone = course["supervisoryTelephone"].asString();
				}
				

				if (course["courseChapter"].isArray())
				{
					Json::Value chapter = course["courseChapter"];

					for (int i = 0; i < chapter.size(); i++)
					{
						User_Chapter_Info stUserChapterInfo;
						if (chapter[i]["createTime"].isInt64())
						{
							long long ltime = chapter[i]["createTime"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.createTime = dateTime.toString("yyyy-MM-dd").toStdString();
						}

						if (chapter[i]["startDate"].isInt64())
						{
							long long ltime = chapter[i]["startDate"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.startDate = dateTime.toString("yyyy-MM-dd").toStdString();
						}

						if (chapter[i]["courseIdFk"].isInt())
						{
							stUserChapterInfo.courseIdFk = chapter[i]["courseIdFk"].asInt();
						}

						if (chapter[i]["endTime"].isInt64())
						{
							long long ltime = chapter[i]["endTime"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.endTime = dateTime.toString("hh:mm").toStdString();
						}


						if (chapter[i]["startTime"].isInt64())
						{
							long long ltime = chapter[i]["startTime"].asInt64();
							QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
							stUserChapterInfo.startTime = dateTime.toString("hh:mm").toStdString();
						}

						if (chapter[i]["id"].isInt())
						{
							stUserChapterInfo.id = chapter[i]["id"].asInt();
						}



						if (chapter[i]["title"].isString())
						{
							stUserChapterInfo.title = chapter[i]["title"].asString();
						}

						if (chapter[i]["liveStatusDicFk"].isInt())
						{
							stUserChapterInfo.liveStatusDickFk = chapter[i]["liveStatusDicFk"].asInt();
						}


						if (chapter[i]["userIdFk"].isString())
						{
							stUserChapterInfo.userIdFk = chapter[i]["userIdFk"].asString();
						}
						//�½��пγ̵�titleΪ��
						stUserChapterInfo.courseTitle = stCourseInfo.title;

						if (chapter[i]["vedios"].isArray())
						{
							Json::Value video = chapter[i]["vedios"];
							for (int j = 0; j < video.size(); j++)
							{
								Video_Info stVideoInfo;
								if (video[j]["id"].isInt())
								{
									stVideoInfo.id = video[j]["id"].asInt();
								}

								if (video[j]["courseId"].isInt())
								{
									stVideoInfo.courseId = video[j]["courseId"].asInt();
								}

								if (video[j]["chapterId"].isInt())
								{
									stVideoInfo.chapterId = video[j]["chapterId"].asInt();
								}

								if (video[j]["vedioName"].isString())
								{
									stVideoInfo.vedioName = video[j]["vedioName"].asString();
								}

								if (video[j]["covers"].isString())
								{
									stVideoInfo.covers = video[j]["covers"].asString();
									if (!stVideoInfo.covers.empty())
										stVideoInfo.covers = m_Realm + stVideoInfo.covers;
								}

								if (video[j]["startTime"].isInt64())
								{
									long long ltime = video[j]["startTime"].asInt64();
									QDateTime dateTime = QDateTime::fromTime_t(ltime / 100);
									stUserChapterInfo.startTime = dateTime.toString("hh:mm:ss").toStdString();
								}

								if (video[j]["type"].isString())
								{
									stVideoInfo.type = video[j]["type"].asString();
								}

								if (video[j]["playUrlLd"].isString())
								{
									stVideoInfo.playUrlLd = video[j]["playUrlLd"].asString();
								}

								if (video[j]["playUrlSd"].isString())
								{
									stVideoInfo.playUrlSd = video[j]["playUrlSd"].asString();
								}

								if (video[j]["playUrlHd"].isString())
								{
									stVideoInfo.playUrlHd = video[j]["playUrlHd"].asString();
								}

								if (video[j]["ossUrl"].isString())
								{
									stVideoInfo.ossUrl = video[j]["ossUrl"].asString();
								}

								if (video[j]["ctreateTime"].isString())
								{
									stVideoInfo.ctreateTime = video[j]["ctreateTime"].asString();
								}

								if (video[j]["modifyTime"].isString())
								{
									stVideoInfo.modifyTime = video[j]["modifyTime"].asString();
								}
								stUserChapterInfo.vedios.push_back(stVideoInfo);

							}

						}
						stCourseDetailMsg.vecChapterInfo.push_back(stUserChapterInfo);
					}
				}

				if (course["schoolVOs"].isObject())
				{
					Json::Value schoolInfo = course["schoolVOs"];
					CourseSchool_Info& courseSchoolInfo = stCourseDetailMsg.stCourseInfo.courseSchoolInfo;
					if (schoolInfo["id"].isInt())
					{
						courseSchoolInfo.id = schoolInfo["id"].asInt();
					}
					if (schoolInfo["sign"].isString())
					{
						courseSchoolInfo.sign = schoolInfo["sign"].asString();
					}
					if (schoolInfo["logo"].isString())
					{
						courseSchoolInfo.logo = schoolInfo["logo"].asString();
					}
					if (schoolInfo["name"].isString())
					{
						courseSchoolInfo.name = schoolInfo["name"].asString();
					}
					if (schoolInfo["intro"].isString())
					{
						courseSchoolInfo.intro = schoolInfo["intro"].asString();
					}
					if (schoolInfo["phone"].isString())
					{
						courseSchoolInfo.phone = schoolInfo["phone"].asString();
					}
				}

				if (course["simpleCourseChapterList"].isArray())
				{
					Json::Value simpleCourseChapterList = course["simpleCourseChapterList"];
					for (int i = 0; i < simpleCourseChapterList.size(); i++)
					{
						Class_Info classInfo;
						if (simpleCourseChapterList[i]["courseId"].isInt())
						{
							classInfo.courseId = simpleCourseChapterList[i]["courseId"].asInt();
						}

						if (simpleCourseChapterList[i]["classId"].isInt())
						{
							classInfo.classId = simpleCourseChapterList[i]["classId"].asInt();
						}

						if (simpleCourseChapterList[i]["period"].isInt())
						{
							classInfo.period = simpleCourseChapterList[i]["period"].asInt();
						}

						if (simpleCourseChapterList[i]["startDate"].isInt64())
						{
							long long startDate = simpleCourseChapterList[i]["startDate"].asInt64();
							QDateTime dateStartDate = QDateTime::fromTime_t(startDate / 1000);
							classInfo.startDate = dateStartDate.toString("yyyy.MM.dd").toStdString();
						}

						if (simpleCourseChapterList[i]["endDate"].isInt64())
						{
							long long endDate = simpleCourseChapterList[i]["endDate"].asInt64();
							QDateTime dateEndDate = QDateTime::fromTime_t(endDate / 1000);
							classInfo.startDate = dateEndDate.toString("yyyy.MM.dd").toStdString();
						}

						stCourseDetailMsg.stCourseInfo.vecClassInfo.push_back(classInfo);
					}

				}
			}
		}
	}
	else
	{
		stCourseDetailMsg.errCode = -1;
		stCourseDetailMsg.errMsg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
	}
	return;
}

void CUserDataCenterInterface::GetChapterInfo(int courseId, int classId, Chapter_Info_Result & stChapterInfoResult)
{
	std::string url = WWW_URL;
	url += "/api/course/queryChatperForFront";
	char szOption[256] = { 0 };
	sprintf(szOption, "?terminalType=1&courseId=%d&classId=%d", courseId, classId);
	url += szOption;

	std::string iResponseStr;
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()requestURL str:%s", rikUrlStr.c_str());
	int nResult = CHttpClient::GetInstance()->Gets(url, iResponseStr);
	//LOG_DEBUG("CUserDataCenterInterface::OldBindPhone()backData str:%s", iResponseStr.c_str());
	if (0 != nResult)
	{
		stChapterInfoResult.err_code = nResult;
		stChapterInfoResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::QQBindPhone(): post data error (%s)", CHttpClient::GetInstance()->GetErrorStr(nResult));
		return;
	}

	if (iResponseStr.empty())
	{
		stChapterInfoResult.err_code = -1;
		stChapterInfoResult.err_msg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::QQBindPhone(): request return string is empty!");
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (!root.isNull())
	{
		if (root["status"].isInt64())
		{
			stChapterInfoResult.err_code = root["status"].asInt64();
		}

		if (root["msg"].isString())
		{
			stChapterInfoResult.err_msg = root["msg"].asString();
		}
		if (root["messageId"].isString())
		{
			stChapterInfoResult.err_msgId = root["messageId"].asString();
		}
		if (0 != stChapterInfoResult.err_code)
		{
			return;
		}

		if (root["data"].isObject())
		{
			Json::Value data = root["data"];
			if (data["chapters"].isArray())
			{
				Json::Value chapter = data["chapters"];

				for (int i = 0; i < chapter.size(); i++)
				{
					User_Chapter_Info stUserChapterInfo;
					stUserChapterInfo.classId = classId;
					if (chapter[i]["createTime"].isInt64())
					{
						long long ltime = chapter[i]["createTime"].asInt64();
						QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
						stUserChapterInfo.createTime = dateTime.toString("yyyy-MM-dd").toStdString();
					}

					if (chapter[i]["startDate"].isInt64())
					{
						long long ltime = chapter[i]["startDate"].asInt64();
						QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
						stUserChapterInfo.startDate = dateTime.toString("yyyy-MM-dd").toStdString();
					}

					if (chapter[i]["courseIdFk"].isInt())
					{
						stUserChapterInfo.courseIdFk = chapter[i]["courseIdFk"].asInt();
					}

					if (chapter[i]["endTime"].isInt64())
					{
						long long ltime = chapter[i]["endTime"].asInt64();
						QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
						stUserChapterInfo.endTime = dateTime.toString("hh:mm").toStdString();
					}


					if (chapter[i]["startTime"].isInt64())
					{
						long long ltime = chapter[i]["startTime"].asInt64();
						QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
						stUserChapterInfo.startTime = dateTime.toString("hh:mm").toStdString();
					}

					if (chapter[i]["id"].isInt())
					{
						stUserChapterInfo.id = chapter[i]["id"].asInt();
					}

					if (chapter[i]["title"].isString())
					{
						stUserChapterInfo.title = chapter[i]["title"].asString();
					}

					if (chapter[i]["liveStatusDicFk"].isInt())
					{
						stUserChapterInfo.liveStatusDickFk = chapter[i]["liveStatusDicFk"].asInt();
					}


					if (chapter[i]["userIdFk"].isString())
					{
						stUserChapterInfo.userIdFk = chapter[i]["userIdFk"].asString();
					}

					if (chapter[i]["vedios"].isArray())
					{
						Json::Value video = chapter[i]["vedios"];
						for (int j = 0; j < video.size(); j++)
						{
							Video_Info stVideoInfo;
							if (video[j]["id"].isInt())
							{
								stVideoInfo.id = video[j]["id"].asInt();
							}

							if (video[j]["courseId"].isInt())
							{
								stVideoInfo.courseId = video[j]["courseId"].asInt();
							}

							if (video[j]["chapterId"].isInt())
							{
								stVideoInfo.chapterId = video[j]["chapterId"].asInt();
							}

							if (video[j]["vedioName"].isString())
							{
								stVideoInfo.vedioName = video[j]["vedioName"].asString();
							}

							if (video[j]["covers"].isString())
							{
								stVideoInfo.covers = video[j]["covers"].asString();
								if (!stVideoInfo.covers.empty())
									stVideoInfo.covers = m_Realm + stVideoInfo.covers;
							}

							if (video[j]["startTime"].isInt64())
							{
								long long ltime = video[j]["startTime"].asInt64();
								QDateTime dateTime = QDateTime::fromTime_t(ltime / 100);
								stUserChapterInfo.startTime = dateTime.toString("hh:mm:ss").toStdString();
							}

							if (video[j]["type"].isString())
							{
								stVideoInfo.type = video[j]["type"].asString();
							}

							if (video[j]["playUrlLd"].isString())
							{
								stVideoInfo.playUrlLd = video[j]["playUrlLd"].asString();
							}

							if (video[j]["playUrlSd"].isString())
							{
								stVideoInfo.playUrlSd = video[j]["playUrlSd"].asString();
							}

							if (video[j]["playUrlHd"].isString())
							{
								stVideoInfo.playUrlHd = video[j]["playUrlHd"].asString();
							}

							if (video[j]["ossUrl"].isString())
							{
								stVideoInfo.ossUrl = video[j]["ossUrl"].asString();
							}

							if (video[j]["ctreateTime"].isString())
							{
								stVideoInfo.ctreateTime = video[j]["ctreateTime"].asString();
							}

							if (video[j]["modifyTime"].isString())
							{
								stVideoInfo.modifyTime = video[j]["modifyTime"].asString();
							}
							stUserChapterInfo.vedios.push_back(stVideoInfo);

						}
					}
					stChapterInfoResult.userChapterInfo.push_back(stUserChapterInfo);
				}
			}
		}
	}
	else
	{
		stChapterInfoResult.err_code = -1;
		stChapterInfoResult.err_msg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
	}
	return;
}

void CUserDataCenterInterface::ModifyChatroomAnnouncement(std::string token, int courseId, int classId, std::string announcement, Custom_MsgV2_Info& stCustomMsgV2Info)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/course/modify-chatroom-announcement";
	rikUrlStr += "?token=";
	rikUrlStr += token;

	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	urlencode(announcement);
	rikUrlStr += "&announcement=" + announcement;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCustomMsgV2Info.err_code = nResult;
		stCustomMsgV2Info.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}
	if (iResponseStr.empty())
	{
		stCustomMsgV2Info.err_code = -1;
		stCustomMsgV2Info.err_msg = QString::fromLocal8Bit("http(s)������ϢΪ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (!root.isNull())
	{
		if (root["status"].isInt64())
		{
			stCustomMsgV2Info.err_code = root["status"].asInt64();
		}
		if (root["messageId"].isString())
		{
			stCustomMsgV2Info.err_msgId = root["messageId"].asString();
		}
		if (root["msg"].isString())
		{
			stCustomMsgV2Info.err_msg = root["msg"].asString();
		}
	}
	else
	{
		stCustomMsgV2Info.err_code = -1;
		stCustomMsgV2Info.err_msg = QString::fromLocal8Bit("������ϢΪ��").toStdString();
	}

	return;
}
void CUserDataCenterInterface::BindCountryCode(BIND_CODE_MSG & stBindCodeMsg)
{
	std::string codeUrl = "https://res.shiguangkey.com/res/code/state-region-code.json";
	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(codeUrl, iResponseStr);

	if (0 != nResult)
	{
		stBindCodeMsg.err_code = -1;
		stBindCodeMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}
	if (iResponseStr.empty())
	{
		stBindCodeMsg.err_code = -1;
		stBindCodeMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (!root.isNull())
	{
		stBindCodeMsg.err_code = 0;
		Bind_InternationalCode_Info stBindCodeInfo;
		Json::Value zoneList = root["zoneList"];
		if (root["messageId"].isString())
		{
			stBindCodeMsg.err_msgId = root["messageId"].asString();
		}
		for (int i = 0; i < zoneList.size(); i++)
		{
			Json::Value codeList = zoneList[i];
			if (codeList["name"].isString()) {
				stBindCodeInfo.name = codeList["name"].asString();
			}
			if (codeList["code"].isString()) {
				stBindCodeInfo.code = codeList["code"].asString();
			}
			stBindCodeMsg.InternationalCodeInfo.push_back(stBindCodeInfo);
		}

	}
	else {
		stBindCodeMsg.err_code = -1;
		stBindCodeMsg.err_msg = QString::fromLocal8Bit("��ȡ��Ϣʧ��").toStdString();
	}
}

void CUserDataCenterInterface::QueryRaiseHandList(std::string token, int courseId, int classId, Raise_Hand_Msg& stRaiseHandMsg)
{
	std::string url = STUDY_URL;
	std::string rikUrlStr = url + "/api/interaction/query-raiseHandList";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	char szOption[256] = { 0 };
	sprintf(szOption, "&courseId=%d&classId=%d&clientType=1&terminalType=1", courseId, classId);
	rikUrlStr += szOption;

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stRaiseHandMsg.err_code = nResult;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stRaiseHandMsg.err_code = -1;
		stRaiseHandMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stRaiseHandMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stRaiseHandMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stRaiseHandMsg.err_msgId = root["messageId"].asString();
	}

	if (root["data"].isObject() && root["data"]["raiseHandList"].isArray())
	{
		Json::Value raiseHandList = root["data"]["raiseHandList"];
		Raise_Hand_Info stRaiseHandInfo;
		for (int i = 0; i < raiseHandList.size(); i++)
		{
			if (raiseHandList[i]["accid"].isInt())
			{
				int accid = raiseHandList[i]["accid"].asInt();
				stRaiseHandInfo.accid = QString::number(accid).toStdString();
			}
			if (raiseHandList[i]["nickname"].isString()) {
				stRaiseHandInfo.nickname = raiseHandList[i]["nickname"].asString();
			}
			if (raiseHandList[i]["status"].isInt()) {
				stRaiseHandInfo.status = raiseHandList[i]["status"].asInt();
			}
			stRaiseHandMsg.vecRaiseHandInfo.push_back(stRaiseHandInfo);
		}
	}
	return;
}



void CUserDataCenterInterface::GetCateInfo(CATE_MSG& stCateMsg)
{
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/cate/query";
	rikUrlStr += "?terminalType=1";

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCateMsg.err_code = nResult;
		stCateMsg.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stCateMsg.err_code = -1;
		stCateMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	Json::Value root;
	Json::Reader reader;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCateMsg.err_code = -1;
		stCateMsg.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		return;
	}
	if (root["status"].isInt64())
	{
		stCateMsg.err_code = root["status"].asInt64();
	}
	if (root["msg"].isString())
	{
		stCateMsg.err_msg = root["msg"].asString();
	}
	if (root["messageId"].isString())
	{
		stCateMsg.err_msgId = root["messageId"].asString();
	}


	if (root["data"].isObject())
	{
		parseJson(root["data"]["list"], stCateMsg.vecCateInfo);
	}
}

void CUserDataCenterInterface::GetTeachQuality(std::string token, int pageIndex, int pageSize, int courseId, std::string courseName, int oneLevel, int twoLevel, int threeLevel, Course_Result & stCourseResult)
{
	char szOption[256] = { 0 };
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/course/queryByTeachQuality";
	rikUrlStr += "?token=" + token;
	if (-1 != courseId)
	{
		rikUrlStr += QString("&courseId=%1").arg(courseId).toStdString();
	}

	if (!courseName.empty())
	{
		rikUrlStr += "&title=" + courseName;
	}

	if (-1 != oneLevel)
	{
		rikUrlStr += QString("&oneLevel=%1").arg(oneLevel).toStdString();
	}

	if (-1 != twoLevel)
	{
		rikUrlStr += QString("&twoLevel=%1").arg(twoLevel).toStdString();
	}

	if (-1 != threeLevel)
	{
		rikUrlStr += QString("&threeLevel=%1").arg(threeLevel).toStdString();
	}

	sprintf(szOption, "&pageIndex=%d&pageSize=%d", pageIndex, pageSize);

	rikUrlStr += szOption;

	std::string iResponseStr;


	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stCourseResult.err_code = nResult;
		stCourseResult.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::GetStudentCourse(): post data error (%s)", CHttpClient::GetInstance()->GetErrorStr(nResult));
		return;
	}

	if (iResponseStr.empty())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::GetStudentCourse(): request return string is empty!");
		return;
	}


	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);
	if (root.isNull())
	{
		stCourseResult.err_code = -1;
		stCourseResult.err_msg = QString::fromLocal8Bit("��Ϣ����ʧ��").toStdString();
		//LOG_ERROR("CUserDataCenterInterface::GetStudentCourse(): request return string is empty!");
		return;
	}

	if (root["status"].isInt64())
	{
		stCourseResult.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		stCourseResult.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		stCourseResult.err_msgId = root["messageId"].asString();
	}

	if (0 != stCourseResult.err_code)
	{
		return;
	}

	if (root["data"].isObject())
	{
		Json::Value  data = root["data"];
		if (data["count"].isInt())
		{
			stCourseResult.totalCount = data["count"].asInt();
		}

		if (data["courses"].isArray())
		{
			Json::Value courses = data["courses"];
			for (int i = 0; i < courses.size(); i++)
			{
				Course_Info stCourseInfo;
				if (courses[i]["id"].isInt())
				{
					stCourseInfo.id = courses[i]["id"].asInt();
				}
				if (courses[i]["classIdFk"].isInt())
				{
					stCourseInfo.classId = courses[i]["classIdFk"].asInt();
				}

				if (courses[i]["period"].isInt())
				{
					stCourseInfo.period = courses[i]["period"].asInt();
				}

				if (courses[i]["placementStatus"].isInt())
				{
					stCourseInfo.placementStatus = courses[i]["placementStatus"].asInt();
				}

				if (courses[i]["title"].isString())
				{
					stCourseInfo.title = courses[i]["title"].asString();
				}

				if (courses[i]["cover"].isString())
				{
					stCourseInfo.cover = courses[i]["cover"].asString();
					stCourseInfo.cover = m_Realm + stCourseInfo.cover;
				}

				if (courses[i]["typeDicFk"].isInt())
				{
					stCourseInfo.courseType = courses[i]["typeDicFk"].asInt();
				}

				stCourseInfo.role = 5703;

				if (courses[i]["liveStatusDicFk"].isInt())
				{
					stCourseInfo.liveStatus = courses[i]["liveStatusDicFk"].asInt();
				}

				if (courses[i]["schoolName"].isString())
				{
					stCourseInfo.schoolName = courses[i]["schoolName"].asString();
				}

				if (courses[i]["unshelveDicFk"].isInt())
				{
					stCourseInfo.unshelveDicFk = courses[i]["unshelveDicFk"].asInt();
				}

				if (courses[i]["shangkeStatusDicFk"].isInt())
				{
					stCourseInfo.shangkeStatusDicFk = courses[i]["shangkeStatusDicFk"].asInt();
				}

				if (courses[i]["chapter"].isString())
				{
					stCourseInfo.endChapterNumber = atoi(courses[i]["chapter"].asString().c_str());
				}

				if (courses[i]["chapterNum"].isString())
				{
					stCourseInfo.chapterNumber = atoi(courses[i]["chapterNum"].asString().c_str());
				}

				if (courses[i]["mainTeacher"].isString())
				{
					stCourseInfo.teacherName = courses[i]["mainTeacher"].asString();
				}

				if (courses[i]["startTime"].isInt64())
				{
					long long ltime = courses[i]["startTime"].asInt64();
					QDateTime dateTime = QDateTime::fromTime_t(ltime / 1000);
					stCourseInfo.nextChapterTime = dateTime.toString("yyyy-MM-dd hh:mm:ss").toStdString();
				}

				stCourseResult.CourseInfo.push_back(stCourseInfo);
			}
		}
	}
}

void CUserDataCenterInterface::GetTeacherPersonalInfo(std::string token, User_Base_Data & stUserBaseData)
{
	std::string url = WWW_URL;
	std::string rikUrlStr = url + "/api/user/teacherInfo";
	rikUrlStr += "?token=";
	rikUrlStr += token;
	rikUrlStr += "&terminalType=1";

	std::string iResponseStr;
	int nResult = CHttpClient::GetInstance()->Gets(rikUrlStr, iResponseStr);
	if (0 != nResult)
	{
		stUserBaseData.err_code = nResult;
		stUserBaseData.err_msg = QString::fromLocal8Bit("��������ʧ��").toStdString();
		return;
	}

	if (iResponseStr.empty())
	{
		stUserBaseData.err_code = -1;
		stUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	Json::Reader reader;
	Json::Value root;
	reader.parse(iResponseStr, root);

	if (root.isNull())
	{
		stUserBaseData.err_code = -1;
		stUserBaseData.err_msg = QString::fromLocal8Bit("������Ϣ����").toStdString();
		return;
	}

	if (root["status"].isInt64())
	{
		stUserBaseData.err_code = root["status"].asInt64();
	}

	if (root["msg"].isString())
	{
		stUserBaseData.err_msg = root["msg"].asString();
	}

	if (root["messageId"].isString())
	{
		stUserBaseData.err_msgId = root["messageId"].asString();
	}

	if (0 != stUserBaseData.err_code)
	{
		return;
	}

	if (root["data"].isObject() && root["data"]["teacher"].isObject())
	{
		Json::Value teacher = root["data"]["teacher"];
		if (teacher["account"].isString())
		{
			stUserBaseData.account = teacher["account"].asString();
		}
		if (teacher["name"].isString())
		{
			stUserBaseData.nick = teacher["name"].asString();
		}
		if (teacher["teiId"].isString())
		{
			std::string str = teacher["teiId"].asString();
			stUserBaseData.userid = atoll(str.c_str());
		}

		if (teacher["headIcon"].isString())
		{
			stUserBaseData.ico = teacher["headIcon"].asString();
		}

		if (teacher["qq"].isString())
		{
			stUserBaseData.qq = teacher["qq"].asString();
		}

		if (teacher["email"].isString())
		{
			stUserBaseData.email = teacher["email"].asString();
		}

		if (teacher["phone"].isString())
		{
			stUserBaseData.phone = teacher["phone"].asString();
		}
	}
	return;
}
